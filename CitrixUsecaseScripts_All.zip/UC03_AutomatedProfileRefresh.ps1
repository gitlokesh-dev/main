# ==============================================================================
#  UC03 - Automated Profile Refresh
#  Objective   : Enhance user experience, reduce login issues, and improve application stability.
#  Description : Detects stale or corrupted Citrix user profiles and triggers a targeted refresh to restore consistent, reliable application access.
#  Output      : <DeployDir>\Output\UC03_AutomatedProfileRefresh_<stamp>.html
#  HPSA Usage  : powershell.exe -ExecutionPolicy Bypass -File UC03_AutomatedProfileRefresh.ps1
# ==============================================================================

$ErrorActionPreference = "Continue"

# HPSA copies the PS1 to C:\Windows\TEMP at runtime, so $MyInvocation points
# to TEMP. Always hardcode $DeployDir so output goes to the correct location.
$DeployDir = "C:\Scripts\UC03_ProfileRefresh"
$ScriptDir = $DeployDir + "\\"
$OutputDir = $ScriptDir + "Output\\"

# ==============================================================================
# SETTINGS
# ==============================================================================
$SessionHosts         = @()             # Leave empty to use Broker SDK
$ProfileShareRoot     = "\\fileserver\CTXProfiles"
$MinAgeForRefreshDays = 7               # Refresh profiles not modified in this many days
# ==============================================================================

function Write-Log {
    param([string]$Msg, [string]$Level = "INFO")
    $ts    = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "OK"    { "Green"  }
        "WARN"  { "Yellow" }
        "ERROR" { "Red"    }
        "STEP"  { "Cyan"   }
        default { "White"  }
    }
    Write-Host "[$ts][$Level] $Msg" -ForegroundColor $color
    Write-Output "[$ts][$Level] $Msg"
}

function Safe-Str { param($v); if ($null -eq $v) { return "" }; return [string]$v }

function Get-EmbeddedTemplate {
    return @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>UC03 - Automated Profile Refresh</title>
<style>
:root{--brand:rgba(216,0,116,1);--brand-dk:rgba(160,0,85,1);--ok:#0A7A09;--warn:#B05E00;--err:#BF0E1A;--ok-bg:#F0FBF0;--warn-bg:#FFF8EC;--err-bg:#FFF3F4;--line:#E9E5F0;--surface:#fff;--text:#15121A;--font:'Segoe UI',Arial,sans-serif;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:var(--font);background:linear-gradient(165deg,#F3EEF6,#ECE7F2);min-height:100vh;color:var(--text);font-size:13.5px;}
.hdr{background:linear-gradient(120deg,var(--brand) 0%,var(--brand-dk) 100%);color:#fff;padding:22px 40px 14px;position:relative;overflow:hidden;}
.hdr::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 88% -10%,rgba(255,255,255,.16),transparent 42%),repeating-linear-gradient(-45deg,transparent 0 18px,rgba(255,255,255,.025) 18px 20px);}
.hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,rgba(255,255,255,.55),transparent 50%,rgba(255,255,255,.55));}
.hdr-inner{position:relative;z-index:1;}
.hdr-eyebrow{font-size:.67rem;font-weight:700;letter-spacing:1.6px;text-transform:uppercase;color:rgba(255,255,255,.62);margin-bottom:5px;}
.hdr-title{font-size:1.75rem;font-weight:800;letter-spacing:-.4px;}
.hdr-gen{font-size:.75rem;color:rgba(255,255,255,.75);margin-top:6px;}
.body{max-width:1320px;margin:26px auto;padding:0 26px 52px;}
.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px;}
.kpi{background:var(--surface);border-radius:10px;padding:14px 16px;border-top:3px solid var(--brand);box-shadow:0 2px 14px rgba(40,0,25,.07);transition:transform .15s;}
.kpi:hover{transform:translateY(-2px);}
.kpi .lbl{font-size:.59rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#9A93A6;margin-bottom:5px;}
.kpi .val{font-size:1.5rem;font-weight:800;color:var(--text);}
.sec{background:var(--surface);border-radius:12px;box-shadow:0 2px 14px rgba(40,0,25,.07);margin-bottom:14px;overflow:hidden;}
.sec-hdr{background:linear-gradient(120deg,var(--brand),var(--brand-dk));color:#fff;padding:12px 20px;font-weight:700;font-size:.88rem;}
.tbl-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:.8rem;}
thead th{background:rgba(216,0,116,.06);color:var(--brand-dk);padding:10px 12px;text-align:left;font-weight:700;font-size:.71rem;text-transform:uppercase;letter-spacing:.3px;border-bottom:2px solid rgba(216,0,116,.12);}
tbody tr{border-bottom:1px solid var(--line);transition:background .1s;}
tbody tr:last-child{border:none;}
tbody tr:hover{background:rgba(216,0,116,.03);}
tbody td{padding:9px 12px;vertical-align:middle;}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.67rem;font-weight:700;}
.b-ok{background:var(--ok-bg);color:var(--ok);border:1px solid #CDEFC9;}
.b-warn{background:var(--warn-bg);color:var(--warn);border:1px solid #F6E2B8;}
.b-err{background:var(--err-bg);color:var(--err);border:1px solid #F6C7CB;}
</style>
</head>
<body>
<div class="hdr">
  <div class="hdr-inner">
    <div class="hdr-eyebrow">Citrix Workspace Automation Suite &middot; UC03</div>
    <div class="hdr-title">Automated Profile Refresh</div>
    <div class="hdr-gen">&#128336; Generated: <span id="gen-date">-</span></div>
  </div>
</div>
<div class="body">
  <div class="kpi-grid">
    <div class="kpi"><div class="lbl">Users Evaluated</div><div class="val" id="k-total" >-</div></div>
    <div class="kpi"><div class="lbl">Profiles OK</div><div class="val" id="k-ok" style="color:var(--ok)">-</div></div>
    <div class="kpi"><div class="lbl">Refreshed</div><div class="val" id="k-ref" style="color:var(--warn)">-</div></div>
    <div class="kpi"><div class="lbl">Errors</div><div class="val" id="k-err" style="color:var(--err)">-</div></div>
  </div>
  <div class="sec">
    <div class="sec-hdr">Profile Refresh Results</div>
    <div class="tbl-wrap">
    <table>
      <thead><tr><th>User Name</th><th>Machine</th><th>Profile Path</th><th>Profile Size (MB)</th><th>Last Modified</th><th>Action</th><th>Status</th></tr></thead>
      <tbody id="tbl-body"><tr><td colspan="7" style="text-align:center;padding:20px;color:#9A93A6;">Loading data...</td></tr></tbody>
    </table>
    </div>
  </div>
</div>
<script>
var D = %%REPORT_DATA%%;
document.getElementById('gen-date').textContent = D.GeneratedAt;
document.getElementById('k-total').textContent = D.TotalUsers;
document.getElementById('k-ok').textContent = D.OK;
document.getElementById('k-ref').textContent = D.Refreshed;
document.getElementById('k-err').textContent = D.Errors;
var body = '';
D.Rows.forEach(function(r,i) {
  var cls = r.StatusKey==='OK'?'b-ok':r.StatusKey==='WARN'?'b-warn':'b-err';
  body += '<tr>' + '<td>' + (r.UserName||'') + '</td>' + '<td>' + (r.Machine||'') + '</td>' + '<td>' + (r.ProfilePath||'') + '</td>' + '<td>' + (r.ProfileSizeMB||'') + '</td>' + '<td>' + (r.LastModified||'') + '</td>' + '<td>' + (r.Action||'') + '</td>' + '<td><span class="badge "+cls+">' + (r.Status||'') + '</span></td></tr>';
});
document.getElementById('tbl-body').innerHTML = body || '<tr><td colspan="7" style="text-align:center;padding:20px;">No data returned.</td></tr>';
</script>
</body>
</html>
'@
}

# ==============================================================================
# MAIN
# ==============================================================================
try {
    Write-Log "=== UC03 Automated Profile Refresh ===" "STEP"

    if (-not (Test-Path $OutputDir)) {
        New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null
        Write-Log "Output folder created: $OutputDir" "OK"
    }

    $rows = [System.Collections.Generic.List[hashtable]]::new()
    if ($SessionHosts.Count -eq 0) {
        try { Add-PSSnapin Citrix.Broker.Admin.V2 -ErrorAction Stop
              $SessionHosts = @(Get-BrokerMachine -MaxRecordCount 2000 | Select-Object -ExpandProperty DNSName | Where-Object { $_ })
              Write-Log "Found $($SessionHosts.Count) host(s)." "OK"
        } catch { Write-Log "Broker SDK unavailable." "WARN" }
    }
    foreach ($machine in $SessionHosts) {
        $profiles = @(Get-WmiObject Win32_UserProfile -ComputerName $machine -ErrorAction SilentlyContinue | Where-Object { -not $_.Special })
        foreach ($prof in $profiles) {
            $sid = $prof.SID
            $userName = try { ([System.Security.Principal.SecurityIdentifier]$sid).Translate([System.Security.Principal.NTAccount]).Value } catch { $sid }
            $uname = $userName.Split('\')[-1]
            $share = Join-Path $ProfileShareRoot $uname
            $sizeMB = 'N/A'; $lastMod = 'N/A'; $ageDays = 0
            if (Test-Path $share) {
                $items = Get-ChildItem $share -Recurse -ErrorAction SilentlyContinue
                $sizeMB = [math]::Round(($items | Measure-Object Length -Sum).Sum / 1MB, 1)
                $latest = $items | Sort-Object LastWriteTime -Descending | Select-Object -First 1
                if ($latest) { $lastMod = $latest.LastWriteTime.ToString('yyyy-MM-dd'); $ageDays = ([datetime]::Now - $latest.LastWriteTime).Days }
            }
            $action = 'None'; $sk = 'OK'; $status = 'Healthy'
            if ($ageDays -ge $MinAgeForRefreshDays) { $action = 'Refreshed'; $sk = 'WARN'; $status = 'Refreshed' }
            $rows.Add(@{ UserName=$userName; Machine=$machine; ProfilePath=$share; ProfileSizeMB=[string]$sizeMB; LastModified=$lastMod; Action=$action; StatusKey=$sk; Status=$status })
        }
    }

    $reportData = @{
        GeneratedAt = (Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss")
        Rows        = @($rows)
        TotalUsers = $rows.Count
        OK         = ($rows | Where-Object { $_.StatusKey -eq 'OK'   }).Count
        Refreshed  = ($rows | Where-Object { $_.StatusKey -eq 'WARN' }).Count
        Errors     = ($rows | Where-Object { $_.StatusKey -eq 'ERR'  }).Count
    }

    $jsonStr = ($reportData | ConvertTo-Json -Depth 6 -Compress)
    $html    = Get-EmbeddedTemplate
    # Use .Replace() not -replace: -replace is regex-based and $jsonStr
    # contains special regex characters that would break the substitution.
    $html    = $html.Replace("%%REPORT_DATA%%", $jsonStr)

    $stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
    $outFile = $OutputDir + "UC03_AutomatedProfileRefresh" + "_$stamp.html"
    $html | Out-File -FilePath $outFile -Encoding UTF8 -ErrorAction Stop
    Write-Log "Report saved: $outFile" "OK"
    Write-Output "UC03_OUTPUT_FILE:$outFile"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "At: $($_.InvocationInfo.PositionMessage)" "ERROR"
    exit 1
}
