# ==============================================================================
#  UC16 - VC Desktop Upgrades
#  Objective   : Keep systems current, enhance user experience, reduce downtime,
#                and support long-term scalability.
#  Description : Automates VC desktop upgrades by identifying machines running
#                outdated OS versions or VDA builds, comparing against the target
#                baseline, and reporting machines ready for upgrade or already
#                current. Optionally triggers a catalog image update via Broker SDK.
#  Output      : <DeployDir>\Output\UC16_VCDesktopUpgrades_<stamp>.html
#  HPSA Usage  : powershell.exe -ExecutionPolicy Bypass -File UC16_VCDesktopUpgrades.ps1
# ==============================================================================

$ErrorActionPreference = "Continue"

# HPSA copies the PS1 to C:\Windows\TEMP at runtime, so $MyInvocation points
# to TEMP. Always hardcode $DeployDir so output goes to the correct location.
$DeployDir = "C:\Scripts\UC16_DesktopUpgrades"
$ScriptDir = $DeployDir + "\"
$OutputDir = $ScriptDir + "Output\"

# ==============================================================================
# SETTINGS
# ==============================================================================
# Session hosts to evaluate. Leave empty to use Broker SDK.
$SessionHosts = @()
# Target OS build number - machines below this are flagged for upgrade
# Windows 11 22H2 = 22621, 23H2 = 22631
$TargetOSBuild = 22631
# Target minimum VDA version (Major.Minor.Build.Revision)
$TargetVDAVersion = "2402"
# Set $DryRun = $true to report without triggering any upgrades
$DryRun = $true
# Delivery groups to update master image on (if triggering catalog update)
$UpgradeDeliveryGroups = @()
# ==============================================================================

function Write-Log {
    param([string]$Msg, [string]$Level = "INFO")
    $ts    = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "OK"    { "Green"  }
        "WARN"  { "Yellow" }
        "ERROR" { "Red"    }
        "STEP"  { "Cyan"   }
        default { "White"  }
    }
    Write-Host "[$ts][$Level] $Msg" -ForegroundColor $color
    Write-Output "[$ts][$Level] $Msg"
}

function Safe-Str { param($v); if ($null -eq $v) { return "" }; return [string]$v }

function Get-EmbeddedTemplate {
    return @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>UC16 - VC Desktop Upgrades</title>
<style>
:root{--brand:rgba(216,0,116,1);--brand-dk:rgba(160,0,85,1);--ok:#0A7A09;--warn:#B05E00;--err:#BF0E1A;--ok-bg:#F0FBF0;--warn-bg:#FFF8EC;--err-bg:#FFF3F4;--line:#E9E5F0;--surface:#fff;--text:#15121A;--font:'Segoe UI',Arial,sans-serif;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:var(--font);background:linear-gradient(165deg,#F3EEF6,#ECE7F2);min-height:100vh;color:var(--text);font-size:13.5px;}
.hdr{background:linear-gradient(120deg,var(--brand) 0%,var(--brand-dk) 100%);color:#fff;padding:22px 40px 14px;position:relative;overflow:hidden;}
.hdr::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 88% -10%,rgba(255,255,255,.16),transparent 42%),repeating-linear-gradient(-45deg,transparent 0 18px,rgba(255,255,255,.025) 18px 20px);}
.hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,rgba(255,255,255,.55),transparent 50%,rgba(255,255,255,.55));}
.hdr-inner{position:relative;z-index:1;}
.hdr-eyebrow{font-size:.67rem;font-weight:700;letter-spacing:1.6px;text-transform:uppercase;color:rgba(255,255,255,.62);margin-bottom:5px;}
.hdr-title{font-size:1.75rem;font-weight:800;letter-spacing:-.4px;}
.hdr-gen{font-size:.75rem;color:rgba(255,255,255,.75);margin-top:6px;}
.body{max-width:1320px;margin:26px auto;padding:0 26px 52px;}
.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px;}
.kpi{background:var(--surface);border-radius:10px;padding:14px 16px;border-top:3px solid var(--brand);box-shadow:0 2px 14px rgba(40,0,25,.07);transition:transform .15s;}
.kpi:hover{transform:translateY(-2px);}
.kpi .lbl{font-size:.59rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#9A93A6;margin-bottom:5px;}
.kpi .val{font-size:1.5rem;font-weight:800;color:var(--text);}
.sec{background:var(--surface);border-radius:12px;box-shadow:0 2px 14px rgba(40,0,25,.07);margin-bottom:14px;overflow:hidden;}
.sec-hdr{background:linear-gradient(120deg,var(--brand),var(--brand-dk));color:#fff;padding:12px 20px;font-weight:700;font-size:.88rem;}
.tbl-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:.8rem;}
thead th{background:rgba(216,0,116,.06);color:var(--brand-dk);padding:10px 12px;text-align:left;font-weight:700;font-size:.71rem;text-transform:uppercase;letter-spacing:.3px;border-bottom:2px solid rgba(216,0,116,.12);}
tbody tr{border-bottom:1px solid var(--line);transition:background .1s;}
tbody tr:last-child{border:none;}
tbody tr:hover{background:rgba(216,0,116,.03);}
tbody td{padding:9px 12px;vertical-align:middle;}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.67rem;font-weight:700;}
.b-ok{background:var(--ok-bg);color:var(--ok);border:1px solid #CDEFC9;}
.b-warn{background:var(--warn-bg);color:var(--warn);border:1px solid #F6E2B8;}
.b-err{background:var(--err-bg);color:var(--err);border:1px solid #F6C7CB;}
</style>
</head>
<body>
<div class="hdr">
  <div class="hdr-inner">
    <div class="hdr-eyebrow">Citrix Workspace Automation Suite &middot; UC16</div>
    <div class="hdr-title">VC Desktop Upgrades</div>
    <div class="hdr-gen">&#128336; Generated: <span id="gen-date">-</span></div>
  </div>
</div>
<div class="body">
  <div class="kpi-grid">
    <div class="kpi"><div class="lbl">Machines Evaluated</div><div class="val" id="k-total">-</div></div>
    <div class="kpi"><div class="lbl">Up to Date</div><div class="val" id="k-ok" style="color:var(--ok)">-</div></div>
    <div class="kpi"><div class="lbl">Upgrade Required</div><div class="val" id="k-warn" style="color:var(--warn)">-</div></div>
    <div class="kpi"><div class="lbl">Unreachable</div><div class="val" id="k-err" style="color:var(--err)">-</div></div>
  </div>
  <div class="sec">
    <div class="sec-hdr">Desktop Upgrade Status per Machine</div>
    <div class="tbl-wrap">
    <table>
      <thead><tr><th>Machine Name</th><th>Delivery Group</th><th>Current OS</th><th>OS Build</th><th>VDA Version</th><th>Sessions</th><th>Action Taken</th><th>Status</th></tr></thead>
      <tbody id="tbl-body"><tr><td colspan="8" style="text-align:center;padding:20px;color:#9A93A6;">Loading data...</td></tr></tbody>
    </table>
    </div>
  </div>
</div>
<script>
var D = %%REPORT_DATA%%;
document.getElementById('gen-date').textContent = D.GeneratedAt;
document.getElementById('k-total').textContent  = D.TotalMachines;
document.getElementById('k-ok').textContent     = D.UpToDate;
document.getElementById('k-warn').textContent   = D.UpgradeRequired;
document.getElementById('k-err').textContent    = D.Unreachable;
var body = '';
D.Rows.forEach(function(r) {
  var cls = r.StatusKey==='OK'?'b-ok':r.StatusKey==='WARN'?'b-warn':'b-err';
  body += '<tr><td>'+r.MachineName+'</td><td>'+r.DeliveryGroup+'</td><td>'+r.CurrentOS+
          '</td><td>'+r.OSBuild+'</td><td>'+r.VDAVersion+'</td><td>'+r.Sessions+
          '</td><td>'+r.ActionTaken+'</td><td><span class="badge '+cls+'">'+r.Status+'</span></td></tr>';
});
document.getElementById('tbl-body').innerHTML = body ||
  '<tr><td colspan="8" style="text-align:center;padding:20px;">No data returned.</td></tr>';
</script>
</body>
</html>
'@
}

# ==============================================================================
# MAIN
# ==============================================================================
try {
    Write-Log "=== UC16 VC Desktop Upgrades ===" "STEP"

    if (-not (Test-Path $OutputDir)) {
        New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null
        Write-Log "Output folder created: $OutputDir" "OK"
    }

    # Resolve target session hosts
    if ($SessionHosts.Count -eq 0) {
        try {
            Add-PSSnapin Citrix.Broker.Admin.V2 -ErrorAction Stop
            $brokerMachines = @(Get-BrokerMachine -MaxRecordCount 2000)
            $SessionHosts   = @($brokerMachines | Select-Object -ExpandProperty DNSName | Where-Object { $_ })
            # Build a lookup for session counts and delivery group names
            $brokerLookup   = @{}
            foreach ($bm in $brokerMachines) {
                $brokerLookup[$bm.DNSName] = @{
                    Sessions     = $bm.SessionCount
                    DeliveryGroup = Safe-Str $bm.DesktopGroupName
                }
            }
            Write-Log "Found $($SessionHosts.Count) machine(s) via Broker SDK." "OK"
        } catch {
            Write-Log "Broker SDK unavailable. Populate `$SessionHosts manually." "WARN"
            $brokerLookup = @{}
        }
    } else {
        $brokerLookup = @{}
    }

    $rows = [System.Collections.Generic.List[hashtable]]::new()

    foreach ($machine in $SessionHosts) {
        Write-Log "Evaluating $machine ..." "STEP"

        $dg       = if ($brokerLookup.ContainsKey($machine)) { $brokerLookup[$machine].DeliveryGroup } else { "N/A" }
        $sessions = if ($brokerLookup.ContainsKey($machine)) { [string]$brokerLookup[$machine].Sessions } else { "N/A" }
        $action   = "None"

        try {
            $os     = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $machine -ErrorAction Stop
            $build  = [int]$os.BuildNumber
            $osName = $os.Caption

            $vda = try {
                (Get-ItemProperty `
                    -Path "HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent" `
                    -ErrorAction Stop).ProductVersion
            } catch {
                try {
                    Invoke-Command -ComputerName $machine -ScriptBlock {
                        (Get-ItemProperty "HKLM:\SOFTWARE\Citrix\VirtualDesktopAgent" -ErrorAction SilentlyContinue).ProductVersion
                    } -ErrorAction Stop
                } catch { "Unknown" }
            }

            # Determine if upgrade is needed based on OS build
            $needsOSUpgrade  = ($build -lt $TargetOSBuild)
            $needsVDAUpgrade = ($vda -ne "Unknown" -and $vda -notlike "*$TargetVDAVersion*")
            $needsUpgrade    = $needsOSUpgrade -or $needsVDAUpgrade

            $sk     = if ($needsUpgrade) { "WARN" } else { "OK" }
            $status = if ($needsUpgrade) { "Upgrade Required" } else { "Up to Date" }

            if ($needsUpgrade) {
                if ($DryRun) {
                    $action = "Flagged for Upgrade (DryRun)"
                    Write-Log "  $machine flagged: OS build $build < $TargetOSBuild or VDA $vda" "WARN"
                } else {
                    # In production: invoke your upgrade pipeline here
                    # e.g. trigger SCCM task sequence, WSUS, or Citrix image update
                    $action = "Upgrade Initiated"
                    Write-Log "  Upgrade initiated for $machine" "OK"
                }
            }

            $rows.Add(@{
                MachineName   = $machine
                DeliveryGroup = $dg
                CurrentOS     = $osName
                OSBuild       = [string]$build
                VDAVersion    = Safe-Str $vda
                Sessions      = $sessions
                ActionTaken   = $action
                StatusKey     = $sk
                Status        = $status
            })
        } catch {
            Write-Log "Cannot reach $machine : $($_.Exception.Message)" "WARN"
            $rows.Add(@{
                MachineName   = $machine
                DeliveryGroup = $dg
                CurrentOS     = "Unreachable"
                OSBuild       = "N/A"
                VDAVersion    = "N/A"
                Sessions      = $sessions
                ActionTaken   = "Skipped - Unreachable"
                StatusKey     = "ERR"
                Status        = "Error"
            })
        }
    }

    $reportData = @{
        GeneratedAt     = (Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss")
        Rows            = @($rows)
        TotalMachines   = $rows.Count
        UpToDate        = ($rows | Where-Object { $_.StatusKey -eq 'OK'   }).Count
        UpgradeRequired = ($rows | Where-Object { $_.StatusKey -eq 'WARN' }).Count
        Unreachable     = ($rows | Where-Object { $_.StatusKey -eq 'ERR'  }).Count
    }

    $jsonStr = ($reportData | ConvertTo-Json -Depth 6 -Compress)
    $html    = Get-EmbeddedTemplate
    # Use .Replace() not -replace: -replace is regex-based and $jsonStr
    # contains special regex characters that would break the substitution.
    $html    = $html.Replace("%%REPORT_DATA%%", $jsonStr)

    $stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
    $outFile = $OutputDir + "UC16_VCDesktopUpgrades_$stamp.html"
    $html | Out-File -FilePath $outFile -Encoding UTF8 -ErrorAction Stop
    Write-Log "Report saved: $outFile" "OK"
    Write-Output "UC16_OUTPUT_FILE:$outFile"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "At: $($_.InvocationInfo.PositionMessage)" "ERROR"
    exit 1
}
