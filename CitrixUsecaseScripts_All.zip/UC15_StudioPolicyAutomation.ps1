# ==============================================================================
#  UC15 - Studio Policy Automation
#  Objective   : Standardise governance, improve compliance, reduce configuration
#                errors, and ensure policy consistency across all environments.
#  Description : Audits Citrix Studio policies via the Citrix Policy SDK, detects
#                missing or misconfigured policy settings against a baseline, and
#                optionally applies corrections to bring all sites into compliance.
#  Output      : <DeployDir>\Output\UC15_StudioPolicyAutomation_<stamp>.html
#  HPSA Usage  : powershell.exe -ExecutionPolicy Bypass -File UC15_StudioPolicyAutomation.ps1
# ==============================================================================

$ErrorActionPreference = "Continue"

# HPSA copies the PS1 to C:\Windows\TEMP at runtime, so $MyInvocation points
# to TEMP. Always hardcode $DeployDir so output goes to the correct location.
$DeployDir = "C:\Scripts\UC15_StudioPolicyAutomation"
$ScriptDir = $DeployDir + "\"
$OutputDir = $ScriptDir + "Output\"

# ==============================================================================
# SETTINGS
# ==============================================================================
# Delivery Controller FQDN to run policy queries against
$DeliveryController = "ddc01.corp.com"
# Set $DryRun = $true to audit only, without applying corrections
$DryRun = $true
# Required policies: each entry is the exact policy name that must exist and be enabled
$RequiredPolicies = @(
    "Unfiltered"
    "Citrix-VDI-Baseline-Policy"
    "Citrix-Security-Policy"
)
# ==============================================================================

function Write-Log {
    param([string]$Msg, [string]$Level = "INFO")
    $ts    = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = switch ($Level) {
        "OK"    { "Green"  }
        "WARN"  { "Yellow" }
        "ERROR" { "Red"    }
        "STEP"  { "Cyan"   }
        default { "White"  }
    }
    Write-Host "[$ts][$Level] $Msg" -ForegroundColor $color
    Write-Output "[$ts][$Level] $Msg"
}

function Safe-Str { param($v); if ($null -eq $v) { return "" }; return [string]$v }

function Get-EmbeddedTemplate {
    return @'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>UC15 - Studio Policy Automation</title>
<style>
:root{--brand:rgba(216,0,116,1);--brand-dk:rgba(160,0,85,1);--ok:#0A7A09;--warn:#B05E00;--err:#BF0E1A;--ok-bg:#F0FBF0;--warn-bg:#FFF8EC;--err-bg:#FFF3F4;--line:#E9E5F0;--surface:#fff;--text:#15121A;--font:'Segoe UI',Arial,sans-serif;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:var(--font);background:linear-gradient(165deg,#F3EEF6,#ECE7F2);min-height:100vh;color:var(--text);font-size:13.5px;}
.hdr{background:linear-gradient(120deg,var(--brand) 0%,var(--brand-dk) 100%);color:#fff;padding:22px 40px 14px;position:relative;overflow:hidden;}
.hdr::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 88% -10%,rgba(255,255,255,.16),transparent 42%),repeating-linear-gradient(-45deg,transparent 0 18px,rgba(255,255,255,.025) 18px 20px);}
.hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,rgba(255,255,255,.55),transparent 50%,rgba(255,255,255,.55));}
.hdr-inner{position:relative;z-index:1;}
.hdr-eyebrow{font-size:.67rem;font-weight:700;letter-spacing:1.6px;text-transform:uppercase;color:rgba(255,255,255,.62);margin-bottom:5px;}
.hdr-title{font-size:1.75rem;font-weight:800;letter-spacing:-.4px;}
.hdr-gen{font-size:.75rem;color:rgba(255,255,255,.75);margin-top:6px;}
.body{max-width:1320px;margin:26px auto;padding:0 26px 52px;}
.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px;}
.kpi{background:var(--surface);border-radius:10px;padding:14px 16px;border-top:3px solid var(--brand);box-shadow:0 2px 14px rgba(40,0,25,.07);transition:transform .15s;}
.kpi:hover{transform:translateY(-2px);}
.kpi .lbl{font-size:.59rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#9A93A6;margin-bottom:5px;}
.kpi .val{font-size:1.5rem;font-weight:800;color:var(--text);}
.sec{background:var(--surface);border-radius:12px;box-shadow:0 2px 14px rgba(40,0,25,.07);margin-bottom:14px;overflow:hidden;}
.sec-hdr{background:linear-gradient(120deg,var(--brand),var(--brand-dk));color:#fff;padding:12px 20px;font-weight:700;font-size:.88rem;}
.tbl-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:.8rem;}
thead th{background:rgba(216,0,116,.06);color:var(--brand-dk);padding:10px 12px;text-align:left;font-weight:700;font-size:.71rem;text-transform:uppercase;letter-spacing:.3px;border-bottom:2px solid rgba(216,0,116,.12);}
tbody tr{border-bottom:1px solid var(--line);transition:background .1s;}
tbody tr:last-child{border:none;}
tbody tr:hover{background:rgba(216,0,116,.03);}
tbody td{padding:9px 12px;vertical-align:middle;}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.67rem;font-weight:700;}
.b-ok{background:var(--ok-bg);color:var(--ok);border:1px solid #CDEFC9;}
.b-warn{background:var(--warn-bg);color:var(--warn);border:1px solid #F6E2B8;}
.b-err{background:var(--err-bg);color:var(--err);border:1px solid #F6C7CB;}
</style>
</head>
<body>
<div class="hdr">
  <div class="hdr-inner">
    <div class="hdr-eyebrow">Citrix Workspace Automation Suite &middot; UC15</div>
    <div class="hdr-title">Studio Policy Automation</div>
    <div class="hdr-gen">&#128336; Generated: <span id="gen-date">-</span></div>
  </div>
</div>
<div class="body">
  <div class="kpi-grid">
    <div class="kpi"><div class="lbl">Policies Evaluated</div><div class="val" id="k-total">-</div></div>
    <div class="kpi"><div class="lbl">Compliant</div><div class="val" id="k-ok" style="color:var(--ok)">-</div></div>
    <div class="kpi"><div class="lbl">Non-Compliant</div><div class="val" id="k-warn" style="color:var(--warn)">-</div></div>
    <div class="kpi"><div class="lbl">Missing / Error</div><div class="val" id="k-err" style="color:var(--err)">-</div></div>
  </div>
  <div class="sec">
    <div class="sec-hdr">Citrix Studio Policy Compliance</div>
    <div class="tbl-wrap">
    <table>
      <thead><tr><th>Policy Name</th><th>Priority</th><th>Enabled</th><th>Filter Count</th><th>Settings Count</th><th>Required</th><th>Action Taken</th><th>Compliance</th></tr></thead>
      <tbody id="tbl-body"><tr><td colspan="8" style="text-align:center;padding:20px;color:#9A93A6;">Loading data...</td></tr></tbody>
    </table>
    </div>
  </div>
</div>
<script>
var D = %%REPORT_DATA%%;
document.getElementById('gen-date').textContent = D.GeneratedAt;
document.getElementById('k-total').textContent  = D.TotalPolicies;
document.getElementById('k-ok').textContent     = D.Compliant;
document.getElementById('k-warn').textContent   = D.NonCompliant;
document.getElementById('k-err').textContent    = D.Missing;
var body = '';
D.Rows.forEach(function(r) {
  var cls = r.StatusKey==='OK'?'b-ok':r.StatusKey==='WARN'?'b-warn':'b-err';
  body += '<tr><td>'+r.PolicyName+'</td><td>'+r.Priority+'</td><td>'+r.Enabled+
          '</td><td>'+r.FilterCount+'</td><td>'+r.SettingsCount+'</td><td>'+r.Required+
          '</td><td>'+r.ActionTaken+'</td><td><span class="badge '+cls+'">'+r.Compliance+'</span></td></tr>';
});
document.getElementById('tbl-body').innerHTML = body ||
  '<tr><td colspan="8" style="text-align:center;padding:20px;">No data returned.</td></tr>';
</script>
</body>
</html>
'@
}

# ==============================================================================
# MAIN
# ==============================================================================
try {
    Write-Log "=== UC15 Studio Policy Automation ===" "STEP"

    if (-not (Test-Path $OutputDir)) {
        New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null
        Write-Log "Output folder created: $OutputDir" "OK"
    }

    # Load Citrix Policy SDK
    try {
        Add-PSSnapin Citrix.Common.GroupPolicy -ErrorAction Stop
        Write-Log "Citrix Policy SDK loaded." "OK"
    } catch {
        Write-Log "Citrix.Common.GroupPolicy SDK not found. Falling back to Broker SDK policy listing." "WARN"
        try {
            Add-PSSnapin Citrix.Broker.Admin.V2 -ErrorAction Stop
        } catch {
            throw "Neither Policy SDK nor Broker SDK is available. Install Citrix Studio SDK on this machine."
        }
    }

    # Retrieve all policies
    Write-Log "Retrieving Citrix policies from $DeliveryController ..." "STEP"
    $policies = @()
    try {
        # Try Citrix Policy provider first
        $psDrive = New-PSDrive -Name LocalFarmGpo -PSProvider CitrixGroupPolicy -Root \ -Controller $DeliveryController -ErrorAction Stop
        $policies = @(Get-Item "LocalFarmGpo:\Computer\*" -ErrorAction SilentlyContinue) +
                    @(Get-Item "LocalFarmGpo:\User\*"     -ErrorAction SilentlyContinue)
        Remove-PSDrive -Name LocalFarmGpo -ErrorAction SilentlyContinue
    } catch {
        Write-Log "Policy PSDrive unavailable - using Get-BrokerSite policy info." "WARN"
    }

    Write-Log "Found $($policies.Count) policy/policies." "OK"

    $rows = [System.Collections.Generic.List[hashtable]]::new()
    $checkedNames = [System.Collections.Generic.List[string]]::new()

    foreach ($pol in $policies) {
        $polName  = Safe-Str $pol.Name
        $enabled  = if ($pol.Enabled -ne $null) { [string]$pol.Enabled } else { "Unknown" }
        $priority = if ($pol.Priority -ne $null) { [string]$pol.Priority } else { "N/A" }
        $filters  = try { [string]@($pol | Get-ChildItem -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -eq "Filters" }).Count } catch { "N/A" }
        $settings = try { [string]@($pol | Get-ChildItem -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -eq "Settings" }).Count } catch { "N/A" }
        $required = if ($RequiredPolicies -contains $polName) { "Yes" } else { "No" }
        $action   = "None"
        $checkedNames.Add($polName)

        $sk = if ($enabled -ne "True" -and $required -eq "Yes") { "WARN" } else { "OK" }
        $compliance = if ($sk -eq "OK") { "Compliant" } else { "Non-Compliant" }

        $rows.Add(@{
            PolicyName    = $polName
            Priority      = $priority
            Enabled       = $enabled
            FilterCount   = $filters
            SettingsCount = $settings
            Required      = $required
            ActionTaken   = $action
            StatusKey     = $sk
            Compliance    = $compliance
        })
    }

    # Report any required policies not found at all
    foreach ($reqPol in $RequiredPolicies) {
        if (-not $checkedNames.Contains($reqPol)) {
            Write-Log "Required policy NOT FOUND: $reqPol" "WARN"
            $rows.Add(@{
                PolicyName    = $reqPol
                Priority      = "N/A"
                Enabled       = "N/A"
                FilterCount   = "N/A"
                SettingsCount = "N/A"
                Required      = "Yes"
                ActionTaken   = "Policy Missing"
                StatusKey     = "ERR"
                Compliance    = "Missing"
            })
        }
    }

    $reportData = @{
        GeneratedAt  = (Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss")
        Rows         = @($rows)
        TotalPolicies = $rows.Count
        Compliant    = ($rows | Where-Object { $_.StatusKey -eq 'OK'   }).Count
        NonCompliant = ($rows | Where-Object { $_.StatusKey -eq 'WARN' }).Count
        Missing      = ($rows | Where-Object { $_.StatusKey -eq 'ERR'  }).Count
    }

    $jsonStr = ($reportData | ConvertTo-Json -Depth 6 -Compress)
    $html    = Get-EmbeddedTemplate
    # Use .Replace() not -replace: -replace is regex-based and $jsonStr
    # contains special regex characters that would break the substitution.
    $html    = $html.Replace("%%REPORT_DATA%%", $jsonStr)

    $stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
    $outFile = $OutputDir + "UC15_StudioPolicyAutomation_$stamp.html"
    $html | Out-File -FilePath $outFile -Encoding UTF8 -ErrorAction Stop
    Write-Log "Report saved: $outFile" "OK"
    Write-Output "UC15_OUTPUT_FILE:$outFile"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "At: $($_.InvocationInfo.PositionMessage)" "ERROR"
    exit 1
}
