############################################################################################################
# Script Name  : StudioPolicyComplianceCheck.ps1
# Use Case     : #10 - Studio Policy Automation
# Description  : Compares Citrix Studio (Group Policy) settings against an expected baseline
#                to catch drift/configuration errors, using the Citrix Group Policy PowerShell
#                SDK (Get-CtxGroupPolicyConfiguration / Get-CtxGroupPolicy cmdlets).
############################################################################################################

#region CONFIG
$OutputDir = "C:\Scripts\StudioPolicyCompliance\output\"
# Expected baseline values -- <-- update to match your organization's approved Studio policy settings.
$ExpectedBaseline = @{
    "SessionIdleTimer"        = "1800"
    "SessionDisconnectTimer"  = "3600"
    "ICAListenerTimeout"      = "150000"
    "ClientClipboardRedirection" = "Allowed"
}
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixPolicySnapin {
    try {
        if (-not (Get-PSSnapin -Name Citrix.GroupPolicy.Commands -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.GroupPolicy.Commands -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix Group Policy snap-in -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Test-PolicyCompliance {
    param([hashtable]$Baseline)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        Set-Location "LocalFarmGpo:\" -ErrorAction Stop
        foreach ($key in $Baseline.Keys) {
            try {
                $setting = Get-ItemProperty -Path ".\Unfiltered" -Name $key -ErrorAction Stop
                $actual  = "$($setting.$key)"
                $rows.Add([pscustomobject]@{
                    Setting  = $key
                    Expected = $Baseline[$key]
                    Actual   = $actual
                    Status   = if ($actual -eq $Baseline[$key]) { "COMPLIANT" } else { "MISMATCH" }
                })
            } catch {
                Write-Log "  Policy setting lookup failed for [$key] -- $($_.Exception.Message)" "WARN"
                $rows.Add([pscustomobject]@{ Setting=$key; Expected=$Baseline[$key]; Actual="NOT SET"; Status="MISMATCH" })
            }
        }
    } catch {
        Write-Log "Could not access LocalFarmGpo:\ PSDrive -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Studio Policy Compliance Check | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/1] Connecting to Citrix Group Policy SDK and comparing against baseline..." "STEP"
    if (-not (Connect-CitrixPolicySnapin)) { throw "Citrix Group Policy PowerShell SDK unavailable on this host." }
    $rows = Test-PolicyCompliance -Baseline $ExpectedBaseline
    $mismatches = @($rows | Where-Object { $_.Status -eq "MISMATCH" }).Count
    Write-Log "  Settings checked: $($rows.Count) | Mismatches: $mismatches" "SUCCESS"

    $ReportData = [pscustomobject]@{
        Title   = "Studio Policy Compliance Check"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Settings Checked" -Value $rows.Count
            New-KpiCard -Label "Compliant" -Value ($rows.Count - $mismatches) -Sub "$($rows.Count) total" -Class "ok"
            New-KpiCard -Label "Mismatches" -Value $mismatches -Class $(if($mismatches -gt 0){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secPolicy" -Title "Policy Setting Compliance" -Type "table" `
                -Columns @("Setting","Expected","Actual","Status") -FilterCols @(3) `
                -Rows (@($rows | ForEach-Object { @($_.Setting,$_.Expected,$_.Actual,$_.Status) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "StudioPolicyComplianceCheck" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
