############################################################################################################
# Script Name  : CIPatchComplianceList.ps1
# Use Case     : #12 - CI List for Patching and Monitoring
# Description  : Generates a Configuration Item (CI) inventory from Active Directory /
#                Citrix Broker, cross-referenced against WSUS patch compliance status, so
#                patch coverage and monitoring gaps are visible in one place.
############################################################################################################

#region CONFIG
$OutputDir  = "C:\Scripts\CIPatchCompliance\output\"
$WsusServer = "wsus.corp.example.com"   # <-- update to your WSUS server
$WsusPort   = 8530
$AdOuFilter = "OU=CitrixServers,DC=corp,DC=example,DC=com"   # <-- update to your CI's AD OU
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-CIInventory {
    param([string]$OuFilter)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $computers = Get-ADComputer -SearchBase $OuFilter -Filter * -Properties OperatingSystem,LastLogonDate -ErrorAction Stop
        foreach ($c in $computers) {
            $rows.Add([pscustomobject]@{
                CIName          = $c.Name
                OperatingSystem = "$($c.OperatingSystem)"
                LastLogon       = if ($c.LastLogonDate) { "$($c.LastLogonDate)" } else { "n/a" }
                Enabled         = if ($c.Enabled) { "YES" } else { "NO" }
            })
        }
    } catch {
        Write-Log "AD computer inventory query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Get-WsusComplianceStatus {
    param([string]$Server,[int]$Port)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        [reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration") | Out-Null
        $wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($Server, $false, $Port)
        $scope = New-Object Microsoft.UpdateServices.Administration.ComputerTargetScope
        foreach ($ct in $wsus.GetComputerTargets($scope)) {
            $summary = $ct.GetUpdateInstallationSummary()
            $rows.Add([pscustomobject]@{
                CIName          = $ct.FullDomainName
                NeededCount     = $summary.NotInstalledCount + $summary.DownloadedCount
                FailedCount     = $summary.FailedCount
                InstalledCount  = $summary.InstalledOrNotApplicableCount
                ComplianceState = if (($summary.NotInstalledCount + $summary.FailedCount) -eq 0) { "COMPLIANT" } else { "NON-COMPLIANT" }
            })
        }
    } catch {
        Write-Log "WSUS compliance query failed against [$Server] -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  CI List for Patching and Monitoring | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Building CI inventory from Active Directory..." "STEP"
    $ciRows = Get-CIInventory -OuFilter $AdOuFilter
    Write-Log "  CIs found: $($ciRows.Count)" "SUCCESS"

    Write-Log "[2/2] Querying WSUS patch compliance..." "STEP"
    $wsusRows = Get-WsusComplianceStatus -Server $WsusServer -Port $WsusPort
    $nonCompliant = @($wsusRows | Where-Object { $_.ComplianceState -eq "NON-COMPLIANT" }).Count
    Write-Log "  WSUS records: $($wsusRows.Count) | Non-compliant: $nonCompliant" "SUCCESS"

    $ReportData = [pscustomobject]@{
        Title   = "CI List for Patching and Monitoring"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "CIs in Inventory" -Value $ciRows.Count
            New-KpiCard -Label "WSUS Records" -Value $wsusRows.Count
            New-KpiCard -Label "Compliant" -Value ($wsusRows.Count - $nonCompliant) -Sub "$($wsusRows.Count) total" -Class "ok"
            New-KpiCard -Label "Non-Compliant" -Value $nonCompliant -Class $(if($nonCompliant -gt 0){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secWsus" -Title "Patch Compliance (WSUS)" -Type "table" `
                -Columns @("CI Name","Needed","Failed","Installed","Compliance State") -FilterCols @(4) `
                -Rows (@($wsusRows | ForEach-Object { @($_.CIName,$_.NeededCount,$_.FailedCount,$_.InstalledCount,$_.ComplianceState) }))
            New-Section -Id "secCI" -Title "CI Inventory (Active Directory)" -Type "table" `
                -Columns @("CI Name","Operating System","Last Logon","Enabled") -FilterCols @(1,3) `
                -Rows (@($ciRows | ForEach-Object { @($_.CIName,$_.OperatingSystem,$_.LastLogon,$_.Enabled) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "CIPatchComplianceList" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
