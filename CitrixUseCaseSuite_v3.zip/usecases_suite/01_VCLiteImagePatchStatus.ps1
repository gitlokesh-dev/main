############################################################################################################
# Script Name  : VCLiteImagePatchStatus.ps1
# Use Case     : #1 - VCLite Image Patching
# Description  : Reports master image patch status, post-patch health checks, and catalog
#                publish status for VCLite Windows 11 master images -- using the Citrix
#                Broker/MCS PowerShell SDK (Citrix.Broker.Admin.V2 / Citrix.MachineCreation.Admin.V2
#                snap-ins). Run on a Citrix Delivery Controller or a host with the Citrix
#                PowerShell SDK installed and 'asnp Citrix.*' available.
############################################################################################################

#region CONFIG
$OutputDir = "C:\Scripts\VCLiteImagePatch\output\"
$CatalogNameFilter = "*VCLite*"   # <-- update to match your MCS catalog naming convention
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixSnapins {
    try {
        if (-not (Get-PSSnapin -Name Citrix.Broker.Admin.V2 -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.* -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix PowerShell snap-ins -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Get-MasterImageStatus {
    param([string]$CatalogFilter)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $catalogs = Get-BrokerCatalog -Name $CatalogFilter -ErrorAction Stop
        foreach ($cat in $catalogs) {
            try {
                $scheme = Get-ProvScheme -ProvisioningSchemeName $cat.ProvisioningSchemeName -ErrorAction Stop
                $lastTask = Get-ProvTask -ErrorAction SilentlyContinue |
                            Where-Object { $_.SchemeId -eq $scheme.ProvisioningSchemeUid } |
                            Sort-Object -Property Created -Descending | Select-Object -First 1
                $rows.Add([pscustomobject]@{
                    Catalog        = $cat.Name
                    MasterImage    = Split-Path $scheme.MasterImageVM -Leaf
                    MachineCount   = $cat.MachineCount
                    LastTaskStatus = if ($lastTask) { "$($lastTask.Status)" } else { "n/a" }
                    LastTaskDate   = if ($lastTask) { "$($lastTask.Created)" } else { "n/a" }
                    Published      = if ($cat.MachineCount -gt 0) { "Yes" } else { "No" }
                })
            } catch {
                Write-Log "  Provisioning scheme lookup failed for catalog [$($cat.Name)] -- $($_.Exception.Message)" "WARN"
            }
        }
    } catch {
        Write-Log "Get-BrokerCatalog query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Get-VdaHealthPostPatch {
    param([string]$CatalogFilter)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $machines = Get-BrokerMachine -CatalogName $CatalogFilter -ErrorAction Stop
        foreach ($m in $machines) {
            $rows.Add([pscustomobject]@{
                MachineName     = $m.MachineName
                RegistrationState = "$($m.RegistrationState)"
                PowerState      = "$($m.PowerState)"
                AgentVersion    = "$($m.AgentVersion)"
                LastConnection  = if ($m.LastConnectionTime) { "$($m.LastConnectionTime)" } else { "n/a" }
                SessionSupport  = "$($m.SessionSupport)"
            })
        }
    } catch {
        Write-Log "Get-BrokerMachine query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  VCLite Image Patch Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/3] Connecting to Citrix Broker PowerShell SDK..." "STEP"
    if (-not (Connect-CitrixSnapins)) { throw "Citrix PowerShell SDK unavailable on this host." }
    Write-Log "Citrix snap-ins loaded." "SUCCESS"

    Write-Log "[2/3] Querying master image / provisioning scheme status..." "STEP"
    $imageRows = Get-MasterImageStatus -CatalogFilter $CatalogNameFilter
    Write-Log "  Catalogs found: $($imageRows.Count)" "SUCCESS"

    Write-Log "[3/3] Querying post-patch VDA health..." "STEP"
    $vdaRows = Get-VdaHealthPostPatch -CatalogFilter $CatalogNameFilter
    $registered = @($vdaRows | Where-Object { $_.RegistrationState -eq "Registered" }).Count
    Write-Log "  VDAs found: $($vdaRows.Count) | Registered: $registered" "SUCCESS"

    $ReportData = [pscustomobject]@{
        Title   = "VCLite Image Patch Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Catalogs" -Value $imageRows.Count -Sub "monitored"
            New-KpiCard -Label "VDAs Total" -Value $vdaRows.Count
            New-KpiCard -Label "VDAs Registered" -Value $registered -Sub "$($vdaRows.Count) total" -Class $(if($registered -eq $vdaRows.Count -and $vdaRows.Count -gt 0){"ok"}else{"warn"})
            New-KpiCard -Label "VDAs Unregistered" -Value ($vdaRows.Count - $registered) -Class $(if(($vdaRows.Count - $registered) -gt 0){"warn"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secImages" -Title "Master Image / Catalog Patch Status" -Type "table" `
                -Columns @("Catalog","Master Image","Machine Count","Last Task Status","Last Task Date","Published") `
                -FilterCols @(0,3,5) `
                -Rows (@($imageRows | ForEach-Object { @($_.Catalog,$_.MasterImage,$_.MachineCount,$_.LastTaskStatus,$_.LastTaskDate,$_.Published) }))
            New-Section -Id "secVda" -Title "Post-Patch VDA Health" -Type "table" `
                -Columns @("Machine Name","Registration State","Power State","Agent Version","Last Connection","Session Support") `
                -FilterCols @(1,2,5) `
                -Rows (@($vdaRows | ForEach-Object { @($_.MachineName,$_.RegistrationState,$_.PowerState,$_.AgentVersion,$_.LastConnection,$_.SessionSupport) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "VCLiteImagePatchStatus" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
