############################################################################################################
# Script Name  : GPOComplianceCheck.ps1
# Use Case     : #4 - Automate weekly user log review to detect if GPO is applied
# Description  : Reviews Group Policy event logs (Event ID 8004 = GPO application failure,
#                1502 = successful processing) across session hosts for the past week, and
#                cross-checks against `gpresult` to confirm expected GPOs are applied.
############################################################################################################

#region CONFIG
$OutputDir     = "C:\Scripts\GPOCompliance\output\"
$SessionHosts  = @("ctx-vda01","ctx-vda02")     # <-- update with your real session host names
$ExpectedGPOs  = @("Citrix-VDA-Baseline","Citrix-Security-Baseline")  # <-- update with your required GPO names
$LookbackDays  = 7
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-GpoEvents {
    param([string[]]$Hosts,[int]$Days)
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $Hosts) {
        try {
            $events = Get-WinEvent -ComputerName $h -FilterHashtable @{
                        LogName = "System"; Id = 1502,8004; StartTime = (Get-Date).AddDays(-$Days)
                      } -ErrorAction Stop
            foreach ($e in $events) {
                $rows.Add([pscustomobject]@{
                    Host      = $h
                    TimeCreated = "$($e.TimeCreated)"
                    EventId   = "$($e.Id)"
                    Result    = if ($e.Id -eq 1502) { "SUCCESS" } else { "FAIL" }
                    Message   = ($e.Message -split "`n")[0]
                })
            }
        } catch {
            Write-Log "  GPO event query failed on [$h] -- $($_.Exception.Message)" "WARN"
        }
    }
    return $rows
}

function Test-GpoApplied {
    param([string[]]$Hosts,[string[]]$Expected)
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $Hosts) {
        try {
            $xmlPath = Join-Path $env:TEMP "gpresult_$h.xml"
            $null = Invoke-Command -ComputerName $h -ScriptBlock {
                        param($p) gpresult /f /x $p 2>$null
                    } -ArgumentList $xmlPath -ErrorAction Stop
            [xml]$gp = Get-Content -Path $xmlPath -ErrorAction Stop
            $appliedNames = @($gp.Rsop.ComputerResults.GPO | ForEach-Object { "$($_.Name)" })
            foreach ($gpo in $Expected) {
                $rows.Add([pscustomobject]@{
                    Host   = $h
                    GPO    = $gpo
                    Status = if ($appliedNames -contains $gpo) { "APPLIED" } else { "MISSING" }
                })
            }
        } catch {
            Write-Log "  gpresult check failed on [$h] -- $($_.Exception.Message)" "WARN"
            foreach ($gpo in $Expected) {
                $rows.Add([pscustomobject]@{ Host=$h; GPO=$gpo; Status="UNKNOWN" })
            }
        }
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Weekly GPO Compliance Check | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Reviewing GPO application event logs (last $LookbackDays day(s))..." "STEP"
    $eventRows = Get-GpoEvents -Hosts $SessionHosts -Days $LookbackDays
    $failCount = @($eventRows | Where-Object { $_.Result -eq "FAIL" }).Count
    Write-Log "  Events found: $($eventRows.Count) (Failures: $failCount)" "SUCCESS"

    Write-Log "[2/2] Verifying expected GPOs are applied (gpresult)..." "STEP"
    $gpoRows = Test-GpoApplied -Hosts $SessionHosts -Expected $ExpectedGPOs
    $missing = @($gpoRows | Where-Object { $_.Status -eq "MISSING" }).Count
    Write-Log "  GPO checks: $($gpoRows.Count) (Missing: $missing)" "SUCCESS"

    $ReportData = [pscustomobject]@{
        Title   = "Weekly GPO Compliance Check"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Hosts Checked" -Value $SessionHosts.Count
            New-KpiCard -Label "GPO Failures ($LookbackDays d)" -Value $failCount -Class $(if($failCount -gt 0){"crit"}else{"ok"})
            New-KpiCard -Label "GPOs Verified" -Value $gpoRows.Count
            New-KpiCard -Label "GPOs Missing" -Value $missing -Class $(if($missing -gt 0){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secGpoStatus" -Title "Expected GPO Application Status" -Type "table" `
                -Columns @("Host","GPO","Status") -FilterCols @(0,1,2) `
                -Rows (@($gpoRows | ForEach-Object { @($_.Host,$_.GPO,$_.Status) }))
            New-Section -Id "secGpoEvents" -Title "GPO Processing Events (Event ID 1502/8004)" -Type "table" `
                -Columns @("Host","Time","Event ID","Result","Message") -FilterCols @(0,3) `
                -Rows (@($eventRows | ForEach-Object { @($_.Host,$_.TimeCreated,$_.EventId,$_.Result,$_.Message) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "GPOComplianceCheck" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
