############################################################################################################
# Script Name  : ProfileRefreshMonitor.ps1
# Use Case     : #2 - Automated Profile Refresh
# Description  : Reports user profile health across session hosts -- profile disk sizes,
#                corruption/misconfiguration events from the Application/Citrix Profile
#                Management event logs, and recent profile-refresh actions. Run from a host
#                with access to the profile share and remote event log read rights on the
#                target session hosts (or run locally per session host via a scheduled task).
############################################################################################################

#region CONFIG
$OutputDir      = "C:\Scripts\ProfileRefresh\output\"
$ProfileShare   = "\\fileserver\profiles$"     # <-- update to your FSLogix/UPM profile share
$SessionHosts   = @("ctx-vda01","ctx-vda02")   # <-- update with your real session host names
$ProfileMgmtLog = "Citrix Profile Management"  # <-- update if using FSLogix ("Microsoft-FSLogix-Apps/Operational")
$LookbackHours  = 24
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-ProfileDiskSummary {
    param([string]$SharePath)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $folders = Get-ChildItem -Path $SharePath -Directory -ErrorAction Stop
        foreach ($f in $folders) {
            try {
                $sizeBytes = (Get-ChildItem -Path $f.FullName -Recurse -File -ErrorAction SilentlyContinue |
                              Measure-Object -Property Length -Sum).Sum
                $sizeMb = if ($sizeBytes) { [math]::Round($sizeBytes / 1MB, 1) } else { 0 }
                $rows.Add([pscustomobject]@{
                    ProfileFolder = $f.Name
                    SizeMB        = $sizeMb
                    LastWrite     = "$($f.LastWriteTime)"
                })
            } catch {
                Write-Log "  Size calc failed for [$($f.Name)] -- $($_.Exception.Message)" "WARN"
            }
        }
    } catch {
        Write-Log "Profile share enumeration failed on '$SharePath' -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Get-ProfileEvents {
    param([string[]]$Hosts,[string]$LogName,[int]$Hours)
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $Hosts) {
        try {
            $events = Get-WinEvent -ComputerName $h -FilterHashtable @{
                        LogName = $LogName; StartTime = (Get-Date).AddHours(-$Hours)
                      } -ErrorAction Stop |
                      Where-Object { $_.LevelDisplayName -in @("Error","Warning") }
            foreach ($e in $events) {
                $rows.Add([pscustomobject]@{
                    Host      = $h
                    TimeCreated = "$($e.TimeCreated)"
                    Level     = "$($e.LevelDisplayName)"
                    EventId   = "$($e.Id)"
                    Message   = ($e.Message -split "`n")[0]
                })
            }
        } catch {
            Write-Log "  Event log query failed on [$h] -- $($_.Exception.Message)" "WARN"
        }
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Automated Profile Refresh Monitor | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Scanning profile share for disk usage..." "STEP"
    $profileRows = Get-ProfileDiskSummary -SharePath $ProfileShare
    Write-Log "  Profiles scanned: $($profileRows.Count)" "SUCCESS"

    Write-Log "[2/2] Querying profile management event logs (last $LookbackHours h)..." "STEP"
    $eventRows = Get-ProfileEvents -Hosts $SessionHosts -LogName $ProfileMgmtLog -Hours $LookbackHours
    $errCount  = @($eventRows | Where-Object { $_.Level -eq "Error" }).Count
    Write-Log "  Events found: $($eventRows.Count) (Errors: $errCount)" "SUCCESS"

    $largeProfiles = @($profileRows | Where-Object { $_.SizeMB -gt 5000 }).Count

    $ReportData = [pscustomobject]@{
        Title   = "Automated Profile Refresh Monitor"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Profiles Scanned" -Value $profileRows.Count
            New-KpiCard -Label "Large Profiles (>5GB)" -Value $largeProfiles -Class $(if($largeProfiles -gt 0){"warn"}else{"ok"})
            New-KpiCard -Label "Profile Events ($LookbackHours h)" -Value $eventRows.Count
            New-KpiCard -Label "Profile Errors ($LookbackHours h)" -Value $errCount -Class $(if($errCount -gt 0){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secProfiles" -Title "Profile Disk Summary" -Type "table" `
                -Columns @("Profile Folder","Size (MB)","Last Write") -FilterCols @() `
                -Rows (@($profileRows | Sort-Object SizeMB -Descending | ForEach-Object { @($_.ProfileFolder,$_.SizeMB,$_.LastWrite) }))
            New-Section -Id "secEvents" -Title "Profile Management Events (Errors/Warnings)" -Type "table" `
                -Columns @("Host","Time","Level","Event ID","Message") -FilterCols @(0,2) `
                -Rows (@($eventRows | ForEach-Object { @($_.Host,$_.TimeCreated,$_.Level,$_.EventId,$_.Message) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "ProfileRefreshMonitor" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
