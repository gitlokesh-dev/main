############################################################################################################
# Script Name  : DesktopUpgradeStatus.ps1
# Use Case     : #11 - Upgrades of the VC Desktops
# Description  : Reports current OS build / agent version per VC desktop against the target
#                version, so upgrade rollout progress can be tracked, using the Citrix Broker
#                PowerShell SDK plus a WMI OS build check.
############################################################################################################

#region CONFIG
$OutputDir      = "C:\Scripts\DesktopUpgrade\output\"
$TargetOsBuild  = "22631"     # <-- update: target Windows build number for this upgrade wave
$TargetAgentVer = "7.42.0.0"  # <-- update: target Citrix VDA agent version
$CatalogFilter  = "*VC*"      # <-- update to match your catalog naming convention
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixSnapins {
    try {
        if (-not (Get-PSSnapin -Name Citrix.Broker.Admin.V2 -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.* -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix PowerShell snap-ins -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Get-DesktopUpgradeStatus {
    param([string]$CatalogFilter,[string]$TargetBuild,[string]$TargetAgent)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $machines = Get-BrokerMachine -CatalogName $CatalogFilter -ErrorAction Stop
        foreach ($m in $machines) {
            $osBuild = "n/a"
            try {
                $os = Get-CimInstance -ComputerName $m.DNSName -ClassName Win32_OperatingSystem -ErrorAction Stop
                $osBuild = "$($os.BuildNumber)"
            } catch {
                Write-Log "  OS build query failed for [$($m.MachineName)] -- $($_.Exception.Message)" "WARN"
            }
            $rows.Add([pscustomobject]@{
                MachineName  = $m.MachineName
                OsBuild      = $osBuild
                AgentVersion = "$($m.AgentVersion)"
                UpgradeStatus = if ($osBuild -eq $TargetBuild -and $m.AgentVersion -eq $TargetAgent) { "UP TO DATE" }
                                elseif ($osBuild -eq "n/a") { "UNKNOWN" }
                                else { "PENDING UPGRADE" }
            })
        }
    } catch {
        Write-Log "Get-BrokerMachine query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  VC Desktop Upgrade Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/1] Connecting to Citrix Broker PowerShell SDK and checking upgrade status..." "STEP"
    if (-not (Connect-CitrixSnapins)) { throw "Citrix PowerShell SDK unavailable on this host." }
    $rows = Get-DesktopUpgradeStatus -CatalogFilter $CatalogFilter -TargetBuild $TargetOsBuild -TargetAgent $TargetAgentVer
    Write-Log "  Machines checked: $($rows.Count)" "SUCCESS"

    $upToDate = @($rows | Where-Object { $_.UpgradeStatus -eq "UP TO DATE" }).Count
    $pending  = @($rows | Where-Object { $_.UpgradeStatus -eq "PENDING UPGRADE" }).Count

    $ReportData = [pscustomobject]@{
        Title   = "VC Desktop Upgrade Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Machines Checked" -Value $rows.Count
            New-KpiCard -Label "Up To Date" -Value $upToDate -Sub "$($rows.Count) total" -Class "ok"
            New-KpiCard -Label "Pending Upgrade" -Value $pending -Class $(if($pending -gt 0){"warn"}else{"ok"})
            New-KpiCard -Label "Target Build" -Value $TargetOsBuild
        )
        Sections = @(
            New-Section -Id "secUpgrade" -Title "Per-Machine Upgrade Status" -Type "table" `
                -Columns @("Machine Name","OS Build","Agent Version","Upgrade Status") -FilterCols @(3) `
                -Rows (@($rows | ForEach-Object { @($_.MachineName,$_.OsBuild,$_.AgentVersion,$_.UpgradeStatus) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "DesktopUpgradeStatus" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
