############################################################################################################
# Script Name  : UnusedVDICleanup.ps1
# Use Case     : #13 - Unused VDI Deletion (last 3 months)
# Description  : Identifies VDIs with no user connection in the last $IdleDays days using the
#                Citrix Broker PowerShell SDK, and deletes them (or previews only, if
#                $WhatIfOnly is $true) to free up compute/storage resources.
############################################################################################################

#region CONFIG
$OutputDir  = "C:\Scripts\UnusedVDICleanup\output\"
$IdleDays   = 90
$WhatIfOnly = $true   # <-- set to $false to actually delete idle machines via Remove-BrokerMachine
$CatalogFilter = "*"  # <-- update to scope this to a specific catalog if needed
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixSnapins {
    try {
        if (-not (Get-PSSnapin -Name Citrix.Broker.Admin.V2 -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.* -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix PowerShell snap-ins -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Get-IdleVDIs {
    param([string]$CatalogFilter,[int]$Days)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $cutoff = (Get-Date).AddDays(-$Days)
        $machines = Get-BrokerMachine -CatalogName $CatalogFilter -SessionSupport Single -ErrorAction Stop
        foreach ($m in $machines) {
            $lastConn = $m.LastConnectionTime
            $isIdle = (-not $lastConn) -or ($lastConn -lt $cutoff)
            $rows.Add([pscustomobject]@{
                MachineName    = $m.MachineName
                LastConnection = if ($lastConn) { "$lastConn" } else { "Never" }
                PowerState     = "$($m.PowerState)"
                CatalogName    = "$($m.CatalogName)"
                IdleStatus     = if ($isIdle) { "IDLE (candidate for deletion)" } else { "ACTIVE" }
            })
        }
    } catch {
        Write-Log "Get-BrokerMachine query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Remove-IdleVDI {
    param([string]$MachineName,[bool]$WhatIf)
    try {
        if ($WhatIf) {
            return "PREVIEW ONLY"
        }
        Remove-BrokerMachine -MachineName $MachineName -Force -ErrorAction Stop
        return "DELETED"
    } catch {
        Write-Log "  Deletion failed for [$MachineName] -- $($_.Exception.Message)" "WARN"
        return "DELETE FAILED"
    }
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Unused VDI Cleanup | Citrix Workspace Automation Suite" "STEP"
    Write-Log "  Mode: $(if($WhatIfOnly){'PREVIEW ONLY -- no VDIs will be deleted'}else{'LIVE -- idle VDIs WILL be deleted'})" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Connecting to Citrix Broker PowerShell SDK and identifying idle VDIs (>$IdleDays days)..." "STEP"
    if (-not (Connect-CitrixSnapins)) { throw "Citrix PowerShell SDK unavailable on this host." }
    $rows = Get-IdleVDIs -CatalogFilter $CatalogFilter -Days $IdleDays
    $idleRows = @($rows | Where-Object { $_.IdleStatus -match '^IDLE' })
    Write-Log "  Machines checked: $($rows.Count) | Idle: $($idleRows.Count)" "SUCCESS"

    Write-Log "[2/2] Processing idle VDIs..." "STEP"
    foreach ($r in $idleRows) {
        $action = Remove-IdleVDI -MachineName $r.MachineName -WhatIf $WhatIfOnly
        $r | Add-Member -NotePropertyName Action -NotePropertyValue $action -Force
    }
    foreach ($r in ($rows | Where-Object { $_.IdleStatus -eq "ACTIVE" })) {
        $r | Add-Member -NotePropertyName Action -NotePropertyValue "N/A" -Force
    }
    Write-Log "  Idle VDI processing complete." "SUCCESS"

    $ReportData = [pscustomobject]@{
        Title   = "Unused VDI Cleanup"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Machines Checked" -Value $rows.Count
            New-KpiCard -Label "Idle (>$IdleDays d)" -Value $idleRows.Count -Class $(if($idleRows.Count -gt 0){"warn"}else{"ok"})
            New-KpiCard -Label "Mode" -Value $(if($WhatIfOnly){"PREVIEW"}else{"LIVE"}) -Class $(if($WhatIfOnly){"warn"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secVdi" -Title "VDI Idle Status & Action" -Type "table" `
                -Columns @("Machine Name","Last Connection","Power State","Catalog","Idle Status","Action") -FilterCols @(2,3,4,5) `
                -Rows (@($rows | Sort-Object LastConnection | ForEach-Object { @($_.MachineName,$_.LastConnection,$_.PowerState,$_.CatalogName,$_.IdleStatus,$_.Action) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "UnusedVDICleanup" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
