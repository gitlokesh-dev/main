############################################################################################################
# Script Name  : ProfileResetFeasibilityAssessment.ps1
# Use Case     : #7 - Assess feasibility of user-triggered profile reset automation
# Description  : This use case is a FEASIBILITY STUDY, not a live automation -- there is no
#                steady-state "report" to run daily. This script instead gathers the current
#                profile-management configuration and recent manual reset frequency so the
#                feasibility assessment has real numbers to work from: which profile solution
#                is in use, whether self-service reset is technically possible today, and how
#                often support tickets currently require a manual reset.
############################################################################################################

#region CONFIG
$OutputDir       = "C:\Scripts\ProfileResetFeasibility\output\"
$SessionHosts    = @("ctx-vda01","ctx-vda02")  # <-- update with your real session host names
$TicketLogPath   = "C:\Scripts\ProfileResetFeasibility\manual_reset_tickets.csv"  # <-- update: export from your ticketing system (columns: Date,User,Host)
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-ProfileSolutionConfig {
    param([string[]]$Hosts)
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $Hosts) {
        try {
            $fslogix = Invoke-Command -ComputerName $h -ScriptBlock {
                Get-ItemProperty -Path "HKLM:\SOFTWARE\FSLogix\Profiles" -ErrorAction SilentlyContinue
            } -ErrorAction Stop
            $upm = Invoke-Command -ComputerName $h -ScriptBlock {
                Get-Service -Name "ProfileMgmt*" -ErrorAction SilentlyContinue
            } -ErrorAction SilentlyContinue
            $rows.Add([pscustomobject]@{
                Host             = $h
                FSLogixEnabled   = if ($fslogix -and $fslogix.Enabled -eq 1) { "YES" } else { "NO" }
                CitrixUPMPresent = if ($upm) { "YES" } else { "NO" }
                SelfServiceReady = if ($fslogix -and $fslogix.Enabled -eq 1) { "LIKELY (container-based, safe to reset)" } else { "NEEDS REVIEW (profile type limits self-service)" }
            })
        } catch {
            Write-Log "  Profile config query failed on [$h] -- $($_.Exception.Message)" "WARN"
            $rows.Add([pscustomobject]@{ Host=$h; FSLogixEnabled="UNKNOWN"; CitrixUPMPresent="UNKNOWN"; SelfServiceReady="UNKNOWN" })
        }
    }
    return $rows
}

function Get-ManualResetHistory {
    param([string]$CsvPath)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        if (-not (Test-Path $CsvPath)) {
            Write-Log "  Ticket history file not found at '$CsvPath' -- skipping (export one from your ticketing system to populate this section)." "WARN"
            return $rows
        }
        $data = Import-Csv -Path $CsvPath -ErrorAction Stop
        foreach ($row in $data) {
            $rows.Add([pscustomobject]@{ Date = "$($row.Date)"; User = "$($row.User)"; Host = "$($row.Host)" })
        }
    } catch {
        Write-Log "  Ticket history import failed -- $($_.Exception.Message)" "WARN"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Profile Reset Feasibility - Current State Assessment | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Checking profile solution configuration across session hosts..." "STEP"
    $configRows = Get-ProfileSolutionConfig -Hosts $SessionHosts
    Write-Log "  Hosts checked: $($configRows.Count)" "SUCCESS"

    Write-Log "[2/2] Reviewing manual profile-reset ticket history..." "STEP"
    $ticketRows = Get-ManualResetHistory -CsvPath $TicketLogPath
    Write-Log "  Manual resets on record: $($ticketRows.Count)" "SUCCESS"

    $readyHosts = @($configRows | Where-Object { $_.SelfServiceReady -match '^LIKELY' }).Count

    $ReportData = [pscustomobject]@{
        Title   = "Profile Reset Feasibility - Current State Assessment"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Hosts Assessed" -Value $configRows.Count
            New-KpiCard -Label "Self-Service Ready" -Value $readyHosts -Sub "$($configRows.Count) total" -Class $(if($readyHosts -eq $configRows.Count -and $configRows.Count -gt 0){"ok"}else{"warn"})
            New-KpiCard -Label "Manual Resets on Record" -Value $ticketRows.Count -Sub "historical ticket volume"
        )
        Sections = @(
            New-Section -Id "secConfig" -Title "Profile Solution Configuration by Host" -Type "table" `
                -Columns @("Host","FSLogix Enabled","Citrix UPM Present","Self-Service Reset Readiness") -FilterCols @(1,2) `
                -Rows (@($configRows | ForEach-Object { @($_.Host,$_.FSLogixEnabled,$_.CitrixUPMPresent,$_.SelfServiceReady) }))
            New-Section -Id "secTickets" -Title "Manual Profile Reset History" -Type "table" `
                -Columns @("Date","User","Host") -FilterCols @(2) `
                -Rows (@($ticketRows | ForEach-Object { @($_.Date,$_.User,$_.Host) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "ProfileResetFeasibility" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  ASSESSMENT COMPLETE -- feed this into the feasibility study document" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
