############################################################################################################
# Script Name  : AppLayerRegionSync.ps1
# Use Case     : #3 - Automate the Layer Transfer Between Regions
# Description  : Reports Citrix App Layering layer version and sync status across regional
#                Enterprise Layer Manager (ELM) appliances, using the App Layering REST API
#                (each ELM exposes a management API, typically https://<elm>/Api/v1).
############################################################################################################

#region CONFIG
$OutputDir = "C:\Scripts\AppLayerRegionSync\output\"
# One entry per region's ELM appliance. <-- update hostnames/credentials for your environment.
$ElmRegions = @(
    @{ Region = "EMEA"; ElmHost = "elm-emea.corp.example.com" }
    @{ Region = "AMER"; ElmHost = "elm-amer.corp.example.com" }
    @{ Region = "APAC"; ElmHost = "elm-apac.corp.example.com" }
)
$ElmApiKey = ""   # <-- update: App Layering API bearer token / key
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-ElmLayers {
    param([string]$Region,[string]$ElmHost,[string]$ApiKey)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $headers = @{ Authorization = "Bearer $ApiKey" }
        $resp = Invoke-RestMethod -Uri "https://$ElmHost/Api/v1/Layers" -Headers $headers -Method Get -TimeoutSec 20 -ErrorAction Stop
        foreach ($layer in @($resp.Items)) {
            $rows.Add([pscustomobject]@{
                Region       = $Region
                LayerName    = "$($layer.Name)"
                Version      = "$($layer.CurrentVersionNumber)"
                LastPublish  = "$($layer.LastPublishedDate)"
                SyncStatus   = "$($layer.SyncStatus)"
            })
        }
    } catch {
        Write-Log "  [$Region] ELM layer query failed on $ElmHost -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  App Layering - Region Sync Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/1] Querying layer status from each region's ELM appliance..." "STEP"
    $allLayers = [System.Collections.Generic.List[object]]::new()
    foreach ($r in $ElmRegions) {
        $rows = Get-ElmLayers -Region $r.Region -ElmHost $r.ElmHost -ApiKey $ElmApiKey
        foreach ($row in $rows) { $allLayers.Add($row) }
        Write-Log "  [$($r.Region)] Layers found: $($rows.Count)" "SUCCESS"
    }

    # Cross-region version-drift check: same layer name, different current version across regions.
    $driftRows = [System.Collections.Generic.List[object]]::new()
    $byName = $allLayers | Group-Object LayerName
    foreach ($g in $byName) {
        $versions = $g.Group.Version | Select-Object -Unique
        if ($versions.Count -gt 1) {
            foreach ($item in $g.Group) {
                $driftRows.Add([pscustomobject]@{ LayerName=$item.LayerName; Region=$item.Region; Version=$item.Version })
            }
        }
    }

    $outOfSync = @($allLayers | Where-Object { $_.SyncStatus -notmatch '(?i)sync' }).Count

    $ReportData = [pscustomobject]@{
        Title   = "App Layering - Region Sync Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Regions" -Value $ElmRegions.Count
            New-KpiCard -Label "Layers Tracked" -Value $allLayers.Count
            New-KpiCard -Label "Version Drift" -Value ($byName | Where-Object { ($_.Group.Version | Select-Object -Unique).Count -gt 1 }).Count -Class $(if($driftRows.Count -gt 0){"warn"}else{"ok"})
            New-KpiCard -Label "Out of Sync" -Value $outOfSync -Class $(if($outOfSync -gt 0){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secLayers" -Title "Layer Status by Region" -Type "table" `
                -Columns @("Region","Layer Name","Version","Last Publish","Sync Status") -FilterCols @(0,4) `
                -Rows (@($allLayers | ForEach-Object { @($_.Region,$_.LayerName,$_.Version,$_.LastPublish,$_.SyncStatus) }))
            New-Section -Id "secDrift" -Title "Cross-Region Version Drift" -Type "table" `
                -Columns @("Layer Name","Region","Version") -FilterCols @(0,1) `
                -Rows (@($driftRows | ForEach-Object { @($_.LayerName,$_.Region,$_.Version) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "AppLayerRegionSync" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
