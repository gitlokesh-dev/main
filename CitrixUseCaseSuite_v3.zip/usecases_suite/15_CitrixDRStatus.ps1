############################################################################################################
# Script Name  : CitrixDRStatus.ps1
# Use Case     : #15 - Citrix DR
# Description  : Reports DR-site readiness -- Delivery Controller/database replication health,
#                DR desktop group standby capacity, and the result of the most recent failover
#                test, using the Citrix Broker PowerShell SDK against both primary and DR sites.
############################################################################################################

#region CONFIG
$OutputDir       = "C:\Scripts\CitrixDR\output\"
$PrimaryDDC      = "ddc-primary.corp.example.com"   # <-- update to your primary Delivery Controller
$DrDDC           = "ddc-dr.corp.example.com"         # <-- update to your DR-site Delivery Controller
$FailoverTestLog = "C:\Scripts\CitrixDR\failover_test_results.csv"  # <-- update: export from your last DR test (columns: TestDate,Result,Notes)
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-SiteServiceStatus {
    param([string]$Site,[string]$DDC)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $services = Get-BrokerServiceInstance -AdminAddress $DDC -ErrorAction Stop
        foreach ($s in $services) {
            $rows.Add([pscustomobject]@{
                Site        = $Site
                ServiceName = "$($s.ServiceName)"
                State       = "$($s.State)"
                MachineName = "$($s.MachineName)"
            })
        }
    } catch {
        Write-Log "  [$Site] Service instance query failed against $DDC -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Get-DrDesktopGroupCapacity {
    param([string]$DDC)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $groups = Get-BrokerDesktopGroup -AdminAddress $DDC -ErrorAction Stop
        foreach ($g in $groups) {
            $rows.Add([pscustomobject]@{
                DesktopGroup = $g.Name
                TotalDesktops = $g.TotalDesktops
                Available    = $g.DesktopsAvailable
                Enabled      = if ($g.Enabled) { "YES" } else { "NO" }
            })
        }
    } catch {
        Write-Log "  DR desktop group query failed against $DDC -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Get-LastFailoverTest {
    param([string]$CsvPath)
    try {
        if (-not (Test-Path $CsvPath)) {
            Write-Log "  Failover test log not found at '$CsvPath' -- skipping." "WARN"
            return $null
        }
        $data = Import-Csv -Path $CsvPath -ErrorAction Stop | Sort-Object TestDate -Descending | Select-Object -First 1
        return $data
    } catch {
        Write-Log "  Failover test log import failed -- $($_.Exception.Message)" "WARN"
        return $null
    }
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Citrix DR Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/3] Checking primary and DR-site service health..." "STEP"
    $svcRows = [System.Collections.Generic.List[object]]::new()
    foreach ($row in (Get-SiteServiceStatus -Site "Primary" -DDC $PrimaryDDC)) { $svcRows.Add($row) }
    foreach ($row in (Get-SiteServiceStatus -Site "DR"      -DDC $DrDDC))      { $svcRows.Add($row) }
    $downServices = @($svcRows | Where-Object { $_.State -ne "OK" }).Count
    Write-Log "  Services checked: $($svcRows.Count) | Not OK: $downServices" "SUCCESS"

    Write-Log "[2/3] Checking DR desktop group standby capacity..." "STEP"
    $capRows = Get-DrDesktopGroupCapacity -DDC $DrDDC
    Write-Log "  DR desktop groups: $($capRows.Count)" "SUCCESS"

    Write-Log "[3/3] Reviewing last failover test result..." "STEP"
    $lastTest = Get-LastFailoverTest -CsvPath $FailoverTestLog
    if ($lastTest) { Write-Log "  Last failover test: $($lastTest.TestDate) -- $($lastTest.Result)" "SUCCESS" }

    $ReportData = [pscustomobject]@{
        Title   = "Citrix DR Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Services Checked" -Value $svcRows.Count
            New-KpiCard -Label "Services Not OK" -Value $downServices -Class $(if($downServices -gt 0){"crit"}else{"ok"})
            New-KpiCard -Label "DR Desktop Groups" -Value $capRows.Count
            New-KpiCard -Label "Last Failover Test" -Value $(if($lastTest){$lastTest.Result}else{"n/a"}) -Sub $(if($lastTest){"$($lastTest.TestDate)"}else{"no record found"}) `
                -Class $(if($lastTest -and $lastTest.Result -match '(?i)pass|success'){"ok"}elseif($lastTest){"crit"}else{""})
        )
        Sections = @(
            New-Section -Id "secSvc" -Title "Primary & DR Service Health" -Type "table" `
                -Columns @("Site","Service Name","State","Machine Name") -FilterCols @(0,2) `
                -Rows (@($svcRows | ForEach-Object { @($_.Site,$_.ServiceName,$_.State,$_.MachineName) }))
            New-Section -Id "secCap" -Title "DR Desktop Group Standby Capacity" -Type "table" `
                -Columns @("Desktop Group","Total Desktops","Available","Enabled") -FilterCols @(3) `
                -Rows (@($capRows | ForEach-Object { @($_.DesktopGroup,$_.TotalDesktops,$_.Available,$_.Enabled) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "CitrixDRStatus" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
