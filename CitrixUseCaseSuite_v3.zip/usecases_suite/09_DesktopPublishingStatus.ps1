############################################################################################################
# Script Name  : DesktopPublishingStatus.ps1
# Use Case     : #9 - Desktop Publishing Automation (for VC Desktop)
# Description  : Reports desktop group publishing status, machine catalog association, and
#                delivery-group entitlement counts using the Citrix Broker PowerShell SDK.
############################################################################################################

#region CONFIG
$OutputDir = "C:\Scripts\DesktopPublishing\output\"
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixSnapins {
    try {
        if (-not (Get-PSSnapin -Name Citrix.Broker.Admin.V2 -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.* -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix PowerShell snap-ins -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Get-DesktopGroupStatus {
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $groups = Get-BrokerDesktopGroup -ErrorAction Stop
        foreach ($g in $groups) {
            $entCount = (Get-BrokerAccessPolicyRule -DesktopGroupUid $g.Uid -ErrorAction SilentlyContinue |
                         Measure-Object).Count
            $rows.Add([pscustomobject]@{
                DesktopGroup   = $g.Name
                Enabled        = if ($g.Enabled) { "YES" } else { "NO" }
                DesktopKind    = "$($g.DesktopKind)"
                TotalMachines  = $g.TotalDesktops
                AvailableDesktops = $g.DesktopsAvailable
                InMaintenance  = $g.DesktopsInMaintenanceMode
                PublishedDate  = "$($g.PublishedName)"
                PolicyRules    = $entCount
            })
        }
    } catch {
        Write-Log "Get-BrokerDesktopGroup query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Desktop Publishing Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/1] Connecting to Citrix Broker PowerShell SDK and querying desktop groups..." "STEP"
    if (-not (Connect-CitrixSnapins)) { throw "Citrix PowerShell SDK unavailable on this host." }
    $rows = Get-DesktopGroupStatus
    Write-Log "  Desktop groups found: $($rows.Count)" "SUCCESS"

    $enabledGroups = @($rows | Where-Object { $_.Enabled -eq "YES" }).Count
    $totalMachines = ($rows | Measure-Object -Property TotalMachines -Sum).Sum
    $totalAvailable = ($rows | Measure-Object -Property AvailableDesktops -Sum).Sum
    $totalMaint    = ($rows | Measure-Object -Property InMaintenance -Sum).Sum

    $ReportData = [pscustomobject]@{
        Title   = "Desktop Publishing Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Desktop Groups" -Value $rows.Count
            New-KpiCard -Label "Enabled Groups" -Value $enabledGroups -Sub "$($rows.Count) total"
            New-KpiCard -Label "Total Machines" -Value $totalMachines
            New-KpiCard -Label "Available Desktops" -Value $totalAvailable
            New-KpiCard -Label "In Maintenance" -Value $totalMaint -Class $(if($totalMaint -gt 0){"warn"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secGroups" -Title "Desktop Group Publishing Status" -Type "table" `
                -Columns @("Desktop Group","Enabled","Desktop Kind","Total Machines","Available","In Maintenance","Published Name","Policy Rules") `
                -FilterCols @(1,2) `
                -Rows (@($rows | ForEach-Object { @($_.DesktopGroup,$_.Enabled,$_.DesktopKind,$_.TotalMachines,$_.AvailableDesktops,$_.InMaintenance,$_.PublishedDate,$_.PolicyRules) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "DesktopPublishingStatus" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
