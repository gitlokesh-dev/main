############################################################################################################
# Script Name  : DriveCleanupReport.ps1
# Use Case     : #5 - Automatic Cleanup Application Drives (D & E)
# Description  : Scans configured cleanup targets (temp folders, old logs, orphaned installer
#                caches) on each session host's application drives, reports reclaimable space,
#                and deletes files older than $RetentionDays. Set $WhatIfOnly = $true to preview
#                without deleting anything.
############################################################################################################

#region CONFIG
$OutputDir     = "C:\Scripts\DriveCleanup\output\"
$SessionHosts  = @("ctx-vda01","ctx-vda02")   # <-- update with your real session host names
$RetentionDays = 14
$WhatIfOnly    = $true    # <-- set to $false to actually delete matched files
$CleanupPaths  = @(       # <-- update to match your environment's real cleanup targets
    "D:\Temp",
    "D:\Logs",
    "E:\InstallerCache"
)
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-DriveFreeSpace {
    param([string]$HostName)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $disks = Get-CimInstance -ComputerName $HostName -ClassName Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction Stop
        foreach ($d in $disks) {
            $rows.Add([pscustomobject]@{
                Host      = $HostName
                Drive     = $d.DeviceID
                SizeGB    = [math]::Round($d.Size / 1GB, 1)
                FreeGB    = [math]::Round($d.FreeSpace / 1GB, 1)
                FreePct   = if ($d.Size -gt 0) { [math]::Round(($d.FreeSpace / $d.Size) * 100, 1) } else { 0 }
            })
        }
    } catch {
        Write-Log "  Disk query failed on [$HostName] -- $($_.Exception.Message)" "WARN"
    }
    return $rows
}

function Invoke-CleanupScan {
    param([string]$HostName,[string[]]$Paths,[int]$Days,[bool]$WhatIf)
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($p in $Paths) {
        try {
            $result = Invoke-Command -ComputerName $HostName -ScriptBlock {
                param($Path,$RetDays,$DryRun)
                if (-not (Test-Path $Path)) { return [pscustomobject]@{ Path=$Path; FileCount=0; ReclaimedMB=0; Action="PATH NOT FOUND" } }
                $cutoff = (Get-Date).AddDays(-$RetDays)
                $files  = Get-ChildItem -Path $Path -Recurse -File -ErrorAction SilentlyContinue |
                          Where-Object { $_.LastWriteTime -lt $cutoff }
                $sizeMb = [math]::Round((($files | Measure-Object -Property Length -Sum).Sum) / 1MB, 1)
                if (-not $DryRun) { $files | Remove-Item -Force -ErrorAction SilentlyContinue }
                [pscustomobject]@{
                    Path = $Path; FileCount = $files.Count; ReclaimedMB = $sizeMb
                    Action = if ($DryRun) { "PREVIEW ONLY" } else { "DELETED" }
                }
            } -ArgumentList $p, $Days, $WhatIf -ErrorAction Stop
            $rows.Add([pscustomobject]@{
                Host = $HostName; Path = $result.Path; FileCount = $result.FileCount
                ReclaimedMB = $result.ReclaimedMB; Action = $result.Action
            })
        } catch {
            Write-Log "  Cleanup scan failed on [$HostName] path [$p] -- $($_.Exception.Message)" "WARN"
            $rows.Add([pscustomobject]@{ Host=$HostName; Path=$p; FileCount=0; ReclaimedMB=0; Action="ERROR" })
        }
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Drive Cleanup Report (D:/E:) | Citrix Workspace Automation Suite" "STEP"
    Write-Log "  Mode: $(if($WhatIfOnly){'PREVIEW ONLY -- no files will be deleted'}else{'LIVE -- matched files WILL be deleted'})" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Checking drive free space across session hosts..." "STEP"
    $diskRows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $SessionHosts) { foreach ($row in (Get-DriveFreeSpace -HostName $h)) { $diskRows.Add($row) } }
    Write-Log "  Disks checked: $($diskRows.Count)" "SUCCESS"

    Write-Log "[2/2] Scanning/cleaning configured paths (retention: $RetentionDays days)..." "STEP"
    $cleanupRows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $SessionHosts) {
        foreach ($row in (Invoke-CleanupScan -HostName $h -Paths $CleanupPaths -Days $RetentionDays -WhatIf $WhatIfOnly)) {
            $cleanupRows.Add($row)
        }
    }
    $totalReclaimedMb = ($cleanupRows | Measure-Object -Property ReclaimedMB -Sum).Sum
    Write-Log "  Total reclaimable/reclaimed: $totalReclaimedMb MB across $($cleanupRows.Count) path(s)" "SUCCESS"

    $lowDisks = @($diskRows | Where-Object { $_.FreePct -lt 15 }).Count

    $ReportData = [pscustomobject]@{
        Title   = "Drive Cleanup Report (D:/E:)"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Hosts Scanned" -Value $SessionHosts.Count
            New-KpiCard -Label "Low Disks (<15% free)" -Value $lowDisks -Class $(if($lowDisks -gt 0){"crit"}else{"ok"})
            New-KpiCard -Label "Total Reclaimed" -Value "$totalReclaimedMb MB"
            New-KpiCard -Label "Mode" -Value $(if($WhatIfOnly){"PREVIEW"}else{"LIVE"}) -Class $(if($WhatIfOnly){"warn"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secDisks" -Title "Drive Free Space" -Type "table" `
                -Columns @("Host","Drive","Size (GB)","Free (GB)","Free %") -FilterCols @(0,1) `
                -Rows (@($diskRows | ForEach-Object { @($_.Host,$_.Drive,$_.SizeGB,$_.FreeGB,$_.FreePct) }))
            New-Section -Id "secCleanup" -Title "Cleanup Scan Results" -Type "table" `
                -Columns @("Host","Path","File Count","Reclaimed (MB)","Action") -FilterCols @(0,4) `
                -Rows (@($cleanupRows | ForEach-Object { @($_.Host,$_.Path,$_.FileCount,$_.ReclaimedMB,$_.Action) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "DriveCleanupReport" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
