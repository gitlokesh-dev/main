############################################################################################################
# Script Name  : CustomerAppTestStatus.ps1
# Use Case     : #16 - Customer Testing --> Multiple Applications
# Description  : Runs a lightweight synthetic-transaction check against each published
#                application (launch reachability + published-app health from the Citrix
#                Broker SDK), and reports pass/fail per application to support pre-production
#                customer testing sign-off.
############################################################################################################

#region CONFIG
$OutputDir = "C:\Scripts\CustomerAppTest\output\"
# Optional: name of a StoreFront/Workspace store to test launch resolution against.
$StoreFrontUrl = "https://storefront.corp.example.com/Citrix/Store/discovery"  # <-- update
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixSnapins {
    try {
        if (-not (Get-PSSnapin -Name Citrix.Broker.Admin.V2 -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.* -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix PowerShell snap-ins -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Test-ApplicationHealth {
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $apps = Get-BrokerApplication -ErrorAction Stop
        foreach ($a in $apps) {
            $desktopGroupOk = $false
            try {
                $dgUid = $a.AssociatedDesktopGroupUids | Select-Object -First 1
                if ($dgUid) {
                    $dg = Get-BrokerDesktopGroup -Uid $dgUid -ErrorAction Stop
                    $desktopGroupOk = ($dg.DesktopsAvailable -gt 0)
                }
            } catch {
                Write-Log "  Desktop group check failed for [$($a.Name)] -- $($_.Exception.Message)" "WARN"
            }
            $rows.Add([pscustomobject]@{
                AppName        = $a.Name
                Enabled        = if ($a.Enabled) { "YES" } else { "NO" }
                CapacityAvailable = if ($desktopGroupOk) { "YES" } else { "NO" }
                TestResult     = if ($a.Enabled -and $desktopGroupOk) { "PASS" } else { "FAIL" }
            })
        }
    } catch {
        Write-Log "Get-BrokerApplication query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Test-StoreFrontReachable {
    param([string]$Url)
    try {
        $resp = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
        return [pscustomobject]@{ Check="StoreFront Discovery URL"; Result="REACHABLE ($($resp.StatusCode))" }
    } catch {
        Write-Log "  StoreFront reachability check failed -- $($_.Exception.Message)" "WARN"
        return [pscustomobject]@{ Check="StoreFront Discovery URL"; Result="UNREACHABLE" }
    }
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Customer Application Testing Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Connecting to Citrix Broker PowerShell SDK and testing published applications..." "STEP"
    if (-not (Connect-CitrixSnapins)) { throw "Citrix PowerShell SDK unavailable on this host." }
    $appRows = Test-ApplicationHealth
    $passCount = @($appRows | Where-Object { $_.TestResult -eq "PASS" }).Count
    Write-Log "  Applications tested: $($appRows.Count) | Pass: $passCount" "SUCCESS"

    Write-Log "[2/2] Checking StoreFront/Workspace reachability..." "STEP"
    $sfCheck = Test-StoreFrontReachable -Url $StoreFrontUrl
    Write-Log "  $($sfCheck.Check): $($sfCheck.Result)" "SUCCESS"

    $failCount = $appRows.Count - $passCount

    $ReportData = [pscustomobject]@{
        Title   = "Customer Application Testing Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Applications Tested" -Value $appRows.Count
            New-KpiCard -Label "Pass" -Value $passCount -Sub "$($appRows.Count) total" -Class "ok"
            New-KpiCard -Label "Fail" -Value $failCount -Class $(if($failCount -gt 0){"crit"}else{"ok"})
            New-KpiCard -Label "StoreFront" -Value $sfCheck.Result -Class $(if($sfCheck.Result -match '(?i)unreachable'){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secApps" -Title "Per-Application Test Results" -Type "table" `
                -Columns @("Application","Enabled","Capacity Available","Test Result") -FilterCols @(1,2,3) `
                -Rows (@($appRows | ForEach-Object { @($_.AppName,$_.Enabled,$_.CapacityAvailable,$_.TestResult) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "CustomerAppTestStatus" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
