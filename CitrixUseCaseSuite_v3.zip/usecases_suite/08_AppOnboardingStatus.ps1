############################################################################################################
# Script Name  : AppOnboardingStatus.ps1
# Use Case     : #8 - Citrix Application Onboarding Automation
# Description  : Reports the status of applications moving through packaging, validation, and
#                deployment -- using Citrix Broker PowerShell SDK for published-application
#                state, and a packaging queue export (App Layering / MSIX packaging tool) for
#                in-flight onboarding requests.
############################################################################################################

#region CONFIG
$OutputDir       = "C:\Scripts\AppOnboarding\output\"
$PackagingQueueCsv = "C:\Scripts\AppOnboarding\packaging_queue.csv"  # <-- update: export from your packaging tool (columns: AppName,Requestor,Stage,SubmittedDate)
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Connect-CitrixSnapins {
    try {
        if (-not (Get-PSSnapin -Name Citrix.Broker.Admin.V2 -ErrorAction SilentlyContinue)) {
            Add-PSSnapin Citrix.* -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Log "Could not load Citrix PowerShell snap-ins -- $($_.Exception.Message)" "ERROR"
        return $false
    }
}

function Get-PublishedAppStatus {
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        $apps = Get-BrokerApplication -ErrorAction Stop
        foreach ($a in $apps) {
            $rows.Add([pscustomobject]@{
                AppName    = $a.Name
                Enabled    = if ($a.Enabled) { "YES" } else { "NO" }
                Visible    = if ($a.Visible) { "YES" } else { "NO" }
                DesktopGroup = ($a.AssociatedDesktopGroupUids -join ',')
                LastChanged  = "$($a.LastModifiedTime)"
            })
        }
    } catch {
        Write-Log "Get-BrokerApplication query failed -- $($_.Exception.Message)" "ERROR"
    }
    return $rows
}

function Get-PackagingQueue {
    param([string]$CsvPath)
    $rows = [System.Collections.Generic.List[object]]::new()
    try {
        if (-not (Test-Path $CsvPath)) {
            Write-Log "  Packaging queue export not found at '$CsvPath' -- skipping." "WARN"
            return $rows
        }
        $data = Import-Csv -Path $CsvPath -ErrorAction Stop
        foreach ($row in $data) {
            $rows.Add([pscustomobject]@{
                AppName       = "$($row.AppName)"
                Requestor     = "$($row.Requestor)"
                Stage         = "$($row.Stage)"
                SubmittedDate = "$($row.SubmittedDate)"
            })
        }
    } catch {
        Write-Log "  Packaging queue import failed -- $($_.Exception.Message)" "WARN"
    }
    return $rows
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  Application Onboarding Status | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/2] Connecting to Citrix Broker PowerShell SDK..." "STEP"
    if (-not (Connect-CitrixSnapins)) { throw "Citrix PowerShell SDK unavailable on this host." }
    $appRows = Get-PublishedAppStatus
    Write-Log "  Published applications found: $($appRows.Count)" "SUCCESS"

    Write-Log "[2/2] Reviewing packaging/onboarding queue..." "STEP"
    $queueRows = Get-PackagingQueue -CsvPath $PackagingQueueCsv
    Write-Log "  In-flight onboarding requests: $($queueRows.Count)" "SUCCESS"

    $enabledCount = @($appRows | Where-Object { $_.Enabled -eq "YES" }).Count
    $inTesting    = @($queueRows | Where-Object { $_.Stage -match '(?i)test|validat' }).Count

    $ReportData = [pscustomobject]@{
        Title   = "Application Onboarding Status"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Published Apps" -Value $appRows.Count
            New-KpiCard -Label "Enabled Apps" -Value $enabledCount -Sub "$($appRows.Count) total"
            New-KpiCard -Label "Onboarding In-Flight" -Value $queueRows.Count
            New-KpiCard -Label "In Testing/Validation" -Value $inTesting -Class $(if($inTesting -gt 0){"warn"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secQueue" -Title "Onboarding Queue" -Type "table" `
                -Columns @("App Name","Requestor","Stage","Submitted Date") -FilterCols @(2) `
                -Rows (@($queueRows | ForEach-Object { @($_.AppName,$_.Requestor,$_.Stage,$_.SubmittedDate) }))
            New-Section -Id "secApps" -Title "Published Application Status" -Type "table" `
                -Columns @("App Name","Enabled","Visible","Desktop Group UID(s)","Last Changed") -FilterCols @(1,2) `
                -Rows (@($appRows | ForEach-Object { @($_.AppName,$_.Enabled,$_.Visible,$_.DesktopGroup,$_.LastChanged) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "AppOnboardingStatus" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
