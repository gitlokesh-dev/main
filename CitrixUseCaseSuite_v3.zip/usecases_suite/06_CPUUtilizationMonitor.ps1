############################################################################################################
# Script Name  : CPUUtilizationMonitor.ps1
# Use Case     : #6 - CPU Utilization Monitoring Request
# Description  : Tracks CPU utilization across Citrix session hosts via CIM/Get-Counter,
#                flags hosts exceeding threshold, to support proactive resource management
#                and scaling decisions.
############################################################################################################

#region CONFIG
$OutputDir     = "C:\Scripts\CPUUtilMonitor\output\"
$SessionHosts  = @("ctx-vda01","ctx-vda02")   # <-- update with your real session host names
$CpuWarnPct    = 75
$CpuCritPct    = 90
#endregion CONFIG

. "$PSScriptRoot\CitrixDashboardCommon.ps1"

#region DATA COLLECTION

function Get-HostCpuUtilization {
    param([string]$HostName)
    try {
        $cpu = (Get-Counter -ComputerName $HostName -Counter "\Processor(_Total)\% Processor Time" -ErrorAction Stop).
                CounterSamples[0].CookedValue
        $mem = Get-CimInstance -ComputerName $HostName -ClassName Win32_OperatingSystem -ErrorAction Stop
        $memUsedPct = [math]::Round((($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / $mem.TotalVisibleMemorySize) * 100, 1)
        $sessions = (Get-CimInstance -ComputerName $HostName -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue).NumberOfUsers
        [pscustomobject]@{
            Host       = $HostName
            CpuPct     = [math]::Round($cpu, 1)
            MemPct     = $memUsedPct
            Sessions   = if ($null -ne $sessions) { $sessions } else { "n/a" }
            Error      = $null
        }
    } catch {
        Write-Log "  CPU/Mem query failed on [$HostName] -- $($_.Exception.Message)" "ERROR"
        [pscustomobject]@{ Host=$HostName; CpuPct=0; MemPct=0; Sessions="n/a"; Error=$_.Exception.Message }
    }
}

#endregion DATA COLLECTION

#region MAIN
try {
    Write-Log "=================================================================" "STEP"
    Write-Log "  CPU Utilization Monitor | Citrix Workspace Automation Suite" "STEP"
    Write-Log "=================================================================" "STEP"

    Write-Log "[1/1] Querying CPU/memory/session counts across session hosts..." "STEP"
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($h in $SessionHosts) {
        $r = Get-HostCpuUtilization -HostName $h
        $r | Add-Member -NotePropertyName Status -NotePropertyValue $(
            if ($r.CpuPct -ge $CpuCritPct) { "CRITICAL" } elseif ($r.CpuPct -ge $CpuWarnPct) { "WARNING" } else { "NORMAL" }
        )
        $rows.Add($r)
        Write-Log ("  [{0}] CPU {1}% | Mem {2}% | Sessions {3}" -f $h,$r.CpuPct,$r.MemPct,$r.Sessions) "SUCCESS"
    }

    $critHosts = @($rows | Where-Object { $_.Status -eq "CRITICAL" }).Count
    $warnHosts = @($rows | Where-Object { $_.Status -eq "WARNING" }).Count
    $avgCpu    = if ($rows.Count -gt 0) { [math]::Round((($rows.CpuPct | Measure-Object -Average).Average),1) } else { 0 }

    $ReportData = [pscustomobject]@{
        Title   = "CPU Utilization Monitor"
        GenDate = Get-Date -Format "dddd, dd MMMM yyyy HH:mm:ss"
        Kpis    = @(
            New-KpiCard -Label "Hosts Monitored" -Value $rows.Count
            New-KpiCard -Label "Average CPU" -Value "$avgCpu%" -Class $(if($avgCpu -ge $CpuCritPct){"crit"}elseif($avgCpu -ge $CpuWarnPct){"warn"}else{"ok"})
            New-KpiCard -Label "Hosts Warning" -Value $warnHosts -Class $(if($warnHosts -gt 0){"warn"}else{"ok"})
            New-KpiCard -Label "Hosts Critical" -Value $critHosts -Class $(if($critHosts -gt 0){"crit"}else{"ok"})
        )
        Sections = @(
            New-Section -Id "secCpu" -Title "Per-Host CPU / Memory / Sessions" -Type "table" `
                -Columns @("Host","CPU %","Memory %","Active Sessions","Status") -FilterCols @(0,4) `
                -Rows (@($rows | Sort-Object CpuPct -Descending | ForEach-Object { @($_.Host,$_.CpuPct,$_.MemPct,$_.Sessions,$_.Status) }))
        )
    }

    $reportFile = Save-DashboardReport -OutputDir $OutputDir -FileNamePrefix "CPUUtilizationMonitor" -ReportData $ReportData `
                               -ScriptName $MyInvocation.MyCommand.Name
    Write-Log "=================================================================" "SUCCESS"
    Write-Log "  DASHBOARD COMPLETE" "SUCCESS"
    if ($reportFile) { Write-Log "HTML File : $reportFile" "SUCCESS" }
    Write-Output "Script Completed: $(Get-Date -Format 'yyyyMMdd_HHmmss')"

} catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log "Stack: $($_.ScriptStackTrace)" "ERROR"
    exit 1
}
#endregion MAIN
